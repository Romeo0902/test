# TK-220 PMS Integration Kit

Material supplied with the Tarnwick Systems TK-220 front-desk key encoder,
firmware 3.12.7 build 00517A04, for property-management integrators and for
field service.

## Contents

| File | What it is |
| --- | --- |
| `TK-220_KX01_Integration_Guide.md` | The KX01 control-port specification: frame format, status values, the complete command reference for every opcode, the record model, the PMS import text format, and worked byte dumps. |
| `kx_client.py` | Sample client. One helper per opcode, field names as in the guide. Standard library only. |
| `kexd-3.12.7-00517A04.map` | Symbol listing for the control-port module, retained for field diagnostics. |
| `src/` | Reference source drop for the control-port module, as shipped to integrators under the source-availability terms of the supply agreement. |

## Start here

Point the sample client at a commissioned unit and run it:

```
python3 kx_client.py <host> 1337
```

It opens one session and walks the unit: device and site record, a page of the
lock map, a guest stay opened on a free room, a credential issued against that
stay and verified at a door, the staff roster, and a journal batch rendered and
fetched as PMS import text. It prints the handles and identifiers the unit
returns at each step, so it doubles as a template for your own integration:
copy `_demo()` and replace the parts you do not need.

To use the client from your own code:

```python
from kx_client import KX

with KX(host, 1337) as kx:
    print(kx.devinfo())
    print(kx.jrnl_count())
```

## Source drop module index

| Module | Responsibility |
| --- | --- |
| `main.c` | Listener, per-connection fork, session loop, opcode dispatch table. |
| `io.c` | Frame read and write on the control port. |
| `state.c` | Static record storage and the record accessors and helpers. |
| `conf.c` | Commissioning files under `/etc/kexd`, read at start. |
| `dev.c` | Device record, site record, clock, counters, diagnostics. |
| `stay.c` | Guest stays: open, amend, close, list. |
| `cred.c` | Credentials: issue, void, read back, verify, card derivation. |
| `door.c` | Lock map, zones, zone lockdown, schedule windows. |
| `staff.c` | Staff roster and staff credential class. |
| `jrnl.c` | Event journal, journal queries, and the export batch commands. |
| `render.c` | The import-text renderers for journal and door batches, and the peek form. |
| `model.c` | Derived views over the lock map and zones used by several commands. |
| `seed.c` | Load of the commissioned data set at start. |
| `kexd.h` | Shared declarations: record types, limits, opcode numbers. |

## Support

Quote the unit serial from the device record and the firmware build above when
raising a case with Tarnwick Systems field support.
