# TK-220 KX01 Control Port — PMS Integration Guide

**Tarnwick Systems Ltd — Front Desk Products Group**

| | |
| --- | --- |
| Product | TK-220 front-desk key encoder |
| Interface | KX01 control port (`kexd`), TCP port 1337 |
| Protocol revision | 12 |
| Applicable firmware | 3.12.7, build `00517A04` |
| Applicable hardware | TK-220, hardware revision 4 |
| Document revision | D |
| Audience | Property-management system (PMS) integrators and site engineers |

## 1. About this guide

The TK-220 encodes guest and staff cards at the front desk, holds the site
lock map, enforces zone schedules and curfews, and keeps an event journal.
The KX01 control port is the interface through which a PMS drives the unit.

A sample client covering every command in this guide ships alongside it as
`kx_client.py`; running it directly walks a commissioned unit end to end and
is the quickest way to see the commands in this guide on the wire. See
`README.md` for the kit contents.

This guide specifies the KX01 wire protocol as implemented by firmware
3.12.7. It covers the frame format, the complete command set, the record
model the commands operate on, the line-oriented import text the unit
renders for PMS batch loads, and the session behaviour an integrator needs
in order to drive the port correctly.

A sample client, `kx_client.py`, ships alongside this guide in the
integration kit. It implements one helper per opcode using the field names
used here.

Conventions used throughout:

* All multi-byte integers are **little-endian** unless stated otherwise.
* Offsets in the request and response tables are counted from the first byte
  of the frame **body**. In a response, offset 0 is the status byte.
* `u8`, `u16`, `u32` are unsigned integers of 1, 2 and 4 bytes; `i8` and
  `i16` are the signed forms.
* `bytes[n]` is a fixed-width field of *n* bytes. Text fields are ASCII and
  are padded to their full width with zero bytes; a companion length field
  gives the number of significant bytes.
* Times are in the unit's own service seconds (see section 4.1) unless the
  field is named otherwise.
* Minute-of-day fields count from 00:00 local, so 0 = 00:00 and 1439 = 23:59.

## 2. Transport

### 2.1 Connection

The control port listens on TCP 1337. A PMS opens a connection, exchanges
command and response frames on it, and closes it. **One connection carries
one session**; there is no session identifier, login step or handshake
requirement, although `HELLO` (0x01) is the conventional first command
because it reports the protocol revision the unit speaks.

The unit serves several sessions at once and accepts a listen backlog of 16
pending connections. Frames on a connection are strictly serialised: the
PMS sends one command frame and reads its response before sending the next.
There are no unsolicited frames; the unit never speaks first.

Record changes made in a session — an opened stay, an issued credential, a
lock-map flag change, a schedule window — are visible to every subsequent
command **in that session**. A PMS that needs to act on a record it has just
created should keep the connection open and continue on it.

### 2.2 Idle behaviour and disconnection

A session runs for at most 60 seconds from the moment the connection is
accepted, after which the unit closes it. A PMS should treat the control
port as a short-lived transaction channel: connect, run the batch of
commands, close. Long-running integrations reconnect per transaction rather
than holding a connection open.

The unit closes the connection when:

* the client closes its end, or the read side reaches end of file;
* a frame is rejected with status `FRAME` (0x01);
* a frame carries an unimplemented opcode and is rejected with status
  `OPCODE` (0x02);
* the 60-second session limit expires.

In every other case — including every body-level rejection — the unit answers
and leaves the connection open for the next command.

### 2.3 Malformed frames

A frame is malformed at the transport level when its magic does not match or
when its body-length field exceeds 4096. In both cases the unit answers with
a one-byte body carrying status `FRAME` (0x01) and then closes the
connection. The response header echoes the opcode byte taken from the
malformed frame.

The unit reads the declared number of body bytes before it reports the
error, so a client that has declared a body length must send that many bytes
if it wants to read the error response rather than time out.

A frame whose header is well formed but whose **body** does not match the
opcode's expected layout is rejected with status `BODY` (0x03) and the
connection stays open.

## 3. Frame format

### 3.1 Header

Every frame — command and response alike — begins with an 8-byte header.

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | bytes[4] | magic | Always the ASCII bytes `K`, `X`, `0`, `1` (`4B 58 30 31`). |
| 4 | u8 | opcode | The command. A response repeats the opcode of the command it answers. |
| 5 | u8 | flags | Bit 0 (`0x01`) is the response bit: 0 in a command, 1 in a response. Remaining bits are reserved and are sent as 0. |
| 6 | u16 | body length | Number of body bytes that follow the header. |

The body follows immediately, with no padding or trailing delimiter. A
command body may be 0 to 4096 bytes.

### 3.2 Response convention

Every response body begins with a one-byte **status**. On status `OK` the
remaining bytes are the response payload described in the command reference.
On any other status the body is exactly one byte long and there is no
payload.

A client therefore reads a response as: 8 header bytes, then `body length`
bytes, then inspects byte 0 of the body.

Responses always carry the opcode of the command that produced them, so a
client can assert opcode agreement as a framing check.

### 3.3 Status values

| Value | Name | Meaning to the operator |
| --- | --- | --- |
| 0x00 | `OK` | The command succeeded. The payload described for that opcode follows. |
| 0x01 | `FRAME` | The frame could not be accepted at the transport level: the magic did not match, or the declared body length was above 4096. The session ends. |
| 0x02 | `OPCODE` | The unit does not implement the opcode in this firmware. The session ends. |
| 0x03 | `BODY` | The body was the wrong length for the opcode, or a field in it fell outside its permitted range. |
| 0x04 | `FULL` | The table the command writes to has no free record. |
| 0x05 | `NOENT` | The record the command names — stay, credential, door, zone, staff member, journal entry — is not present. |
| 0x06 | `STATE` | The record exists but is not in a state the command can act on: a stay that is not open, a credential that is not active, a room already occupied. |
| 0x07 | `DENY` | The request is well formed and the records exist, but site policy refuses it: a stay extension beyond the maximum length, or a staff credential asking for zones the staff record does not hold. |

## 4. Command reference

Opcodes are grouped by function and are listed in numeric order within each
group. Unless a command's entry says otherwise, its request body is empty
and a body of any other length is answered with `BODY`.

Every command in the reference can return `FRAME` and `OPCODE` at the
transport level; those two are not repeated in the per-command status lists.

### 4.1 Device, site, clock, counters and diagnostics — 0x01 to 0x08

The unit keeps two clocks. **Service seconds** is the unit's own monotonic
service time base, counted from the point at which the encoder was
commissioned; it is the time base used by every record timestamp, by
credential expiry, and by the `at` argument of `CRED_VERIFY`. **Host
seconds** is the calendar clock, in seconds since the Unix epoch. Both are
reported by `CLOCK_GET`.

---

#### 0x01 `HELLO`

Greets the unit and returns the identity summary a PMS uses to confirm it is
talking to a compatible encoder.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `model` | Model number. 220 on this product. |
| 3 | u16 | `hw_rev` | Hardware revision. |
| 5 | u16 | `protocol` | KX01 protocol revision. 12 in this firmware. |
| 7 | u32 | `build` | Firmware build identifier. |
| 11 | u32 | `uptime` | Seconds since the unit last started. |
| 15 | u32 | `stays_open` | Number of stays currently open. |
| 19 | u16 | `caps` | Capability bit set. Bit *n* set means the unit implements optional feature group *n*. |

Total response body: 21 bytes.

Statuses: `OK`, `BODY`.

---

#### 0x02 `DEVINFO`

Returns the full device record: the identity plate of the encoder.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | bytes[16] | `serial` | Unit serial, zero-padded ASCII. |
| 17 | bytes[6] | `mac` | Management MAC address, most significant octet first. |
| 23 | u8 | `fw_major` | Firmware major version. |
| 24 | u8 | `fw_minor` | Firmware minor version. |
| 25 | u8 | `fw_patch` | Firmware patch version. |
| 26 | u8 | `hw_rev` | Hardware revision. |
| 27 | u32 | `build` | Firmware build identifier. |
| 31 | u32 | `service_offset` | Service seconds elapsed between commissioning and the current start of the unit. |
| 35 | u16 | `caps` | Capability bit set, as in `HELLO`. |
| 37 | u16 | reserved | Sent as 0. |

Total response body: 39 bytes.

Statuses: `OK`, `BODY`.

---

#### 0x03 `CLOCK_GET`

Reads the clock block.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `device_seconds` | Current service seconds. |
| 5 | u32 | `host_seconds` | Current calendar time, seconds since the Unix epoch. |
| 9 | i16 | `tz_min` | Local offset from UTC in minutes. Range -720 to 840. |
| 11 | u8 | `dst` | 1 while daylight saving is in effect, otherwise 0. |
| 12 | i8 | `drift_ppm` | Measured oscillator drift in parts per million. |
| 13 | u32 | `sync_age` | Seconds since the last successful time synchronisation. |

Total response body: 17 bytes.

Statuses: `OK`, `BODY`.

---

#### 0x04 `CLOCK_SET`

Sets the local time offset and the daylight-saving flag. Writes a journal
entry of kind 13.

Request body (3 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | i16 | `tz_min` | -720 to 840 |
| 2 | u8 | `dst` | 0 or 1 |

Response payload: identical to `CLOCK_GET`, reflecting the new settings.
Total response body: 17 bytes.

Statuses: `OK`, `BODY`.

---

#### 0x05 `DIAG_SELFTEST`

Runs the encoder self-test suite and returns one entry per test. Writes a
journal entry of kind 14.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `count` | Number of test entries that follow. 8 in this firmware. |
| 2 + 4*i* | u8 | `test_no` | Test number, 1 to `count`. |
| 3 + 4*i* | u8 | `result` | 0 = pass, 1 = attention. |
| 4 + 4*i* | u16 | `detail` | Test-specific measurement, as listed below. |

| Test | Subject | `detail` reports |
| --- | --- | --- |
| 1 | Encoder head | Head fault count. |
| 2 | Reader temperature | Reader temperature in tenths of a degree Celsius. |
| 3 | Time synchronisation | Seconds since last synchronisation. |
| 4 | Journal | Journal entries held. |
| 5 | Lock map reachability | Doors online. |
| 6 | Lock map exceptions | Doors offline. Reported with `result` = 1 so the site sees the exception count. |
| 7 | Mains supply | Mains events recorded. |
| 8 | Reserved | 0. |

Total response body: 34 bytes.

Statuses: `OK`, `BODY`.

---

#### 0x06 `DIAG_TEXT`

Returns the same diagnostic material as a human-readable page, for pasting
into a service ticket. Lines are separated by a single LF (`0x0A`) and the
page has no trailing newline.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `text_len` | Number of text bytes that follow. |
| 3 | bytes[`text_len`] | `text` | Printable ASCII diagnostic page. |

Statuses: `OK`, `BODY`.

---

#### 0x07 `COUNTERS`

Returns the maintenance counter block as 17 unsigned 32-bit values in a
fixed order.

Request body: empty.

Response payload: status at offset 0, then value *i* (0-based) at offset
`1 + 4*i*`.

| *i* | Field | Meaning |
| --- | --- | --- |
| 0 | `uptime` | Seconds since the unit last started. |
| 1 | `device_seconds` | Current service seconds. |
| 2 | `cards_encoded` | Cards encoded over the life of the unit. |
| 3 | `cards_voided` | Cards voided over the life of the unit. |
| 4 | `head_cycles` | Encoder head cycles. |
| 5 | `head_faults` | Encoder head faults. |
| 6 | `mains_events` | Mains supply events. |
| 7 | `reader_resets` | Reader resets. |
| 8 | `reader_temp` | Reader temperature in tenths of a degree Celsius. |
| 9 | `doors_provisioned` | Doors in the lock map. |
| 10 | `doors_online` | Doors currently reachable. |
| 11 | `doors_offline` | Doors currently unreachable. |
| 12 | `doors_lowbatt` | Doors flagged low battery. |
| 13 | `zones_in_service` | Zones in service. |
| 14 | `zones_lockdown` | Zones currently in lockdown. |
| 15 | `stays_open` | Stays currently open. |
| 16 | `stays_closed` | Stays currently closed. |

Total response body: 69 bytes.

Statuses: `OK`, `BODY`.

---

#### 0x08 `SITE_INFO`

Returns the site record: the property this encoder is commissioned for.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `name_len` | Significant bytes of `name`, 0 to 40. |
| 2 | bytes[40] | `name` | Site name, zero-padded. |
| 42 | u8 | `addr_len` | Significant bytes of `addr`, 0 to 64. |
| 43 | bytes[64] | `addr` | Site address, zero-padded. |
| 107 | u8 | `inst_len` | Significant bytes of `inst`, 0 to 32. |
| 108 | bytes[32] | `inst` | Installer of record, zero-padded. |
| 140 | u8 | `tick_len` | Significant bytes of `tick`, 0 to 16. |
| 141 | bytes[16] | `tick` | Commissioning ticket reference, zero-padded. |
| 157 | u32 | `service_offset` | As in `DEVINFO`. |
| 161 | u16 | `site_id` | Site identifier held by the unit. |
| 163 | u16 | reserved | Sent as 0. |

Total response body: 165 bytes.

Statuses: `OK`, `BODY`.

### 4.2 Stays — 0x10 to 0x16

A stay is the front-desk record of a room occupancy. It carries a handle,
the room, the party size, the arrival and departure times, the guest name as
supplied by the PMS, and a count of the credentials issued against it.
Handles are allocated from the stay table and are stable for the life of the
record.

---

#### 0x10 `STAY_OPEN`

Opens a stay on a guest room and returns its handle. Writes a journal entry
of kind 1 carrying the supplied name.

Request body (5 + `name_len` bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `room_no` | A room number present in the lock map. |
| 2 | u8 | `party` | 1 to 8 |
| 3 | u8 | `nights` | 1 to 28 |
| 4 | u8 | `name_len` | 0 to 64 |
| 5 | bytes[`name_len`] | `name` | Guest name as the PMS holds it. |

The body length must be exactly `5 + name_len`.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `handle` | Handle of the new stay. |
| 5 | u32 | `check_in` | Arrival, in service seconds. |
| 9 | u32 | `check_out` | Departure, `nights` whole days after arrival. |

Total response body: 13 bytes.

Statuses: `OK`; `BODY`; `NOENT` when the room is not in the lock map;
`STATE` when another open stay already holds the room; `FULL` when the stay
table has no free record.

---

#### 0x11 `STAY_CLOSE`

Closes an open stay and voids every active credential the stay owns. Writes
a journal entry of kind 2 carrying the guest name.

Request body (4 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `handle` | Handle of an open stay. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `handle` | Handle of the closed stay. |
| 5 | u16 | `voided` | Credentials voided by this close. |

Total response body: 7 bytes.

Statuses: `OK`; `BODY`; `NOENT`; `STATE` when the stay is not open.

---

#### 0x12 `STAY_GET`

Reads one stay record.

Request body (4 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `handle` | Handle of a stay. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `handle` | Stay handle. |
| 5 | u16 | `room_no` | Room. |
| 7 | u8 | `state` | 1 = open, 2 = closed. |
| 8 | u8 | `party` | Party size. |
| 9 | u32 | `check_in` | Arrival, service seconds. |
| 13 | u32 | `check_out` | Departure, service seconds. For a closed stay this is the time the stay was closed. |
| 17 | u16 | `cred_count` | Credentials issued against the stay. |
| 19 | u8 | `name_len` | Significant bytes of `name`, 0 to 64. |
| 20 | bytes[64] | `name` | Guest name, zero-padded. |

Total response body: 84 bytes.

Statuses: `OK`, `BODY`, `NOENT`.

---

#### 0x13 `STAY_LIST`

Pages through the stay table. Open and closed stays are both listed.

Request body (2 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `first` | Index of the first matching stay to return, 0-based. |
| 1 | u8 | `count` | Rows to return, 0 to 64. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `returned` | Rows in this response. |
| 2 | u8 | `total` | Stays in the table, ignoring `first` and `count`. |
| 3 + 8*i* | u32 | `handle` | Stay handle. |
| 7 + 8*i* | u16 | `room_no` | Room. |
| 9 + 8*i* | u8 | `state` | 1 = open, 2 = closed. |
| 10 + 8*i* | u8 | `party` | Party size. |

Total response body: `3 + 8 * returned` bytes.

Statuses: `OK`; `BODY` when `count` is above 64.

---

#### 0x14 `STAY_EXTEND`

Pushes the departure of an open stay out by whole nights. Writes a journal
entry of kind 3 carrying the guest name.

Request body (5 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `handle` | Handle of an open stay. |
| 4 | u8 | `nights` | 1 to 28 |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `handle` | Stay handle. |
| 5 | u32 | `check_out` | New departure, service seconds. |

Total response body: 9 bytes.

Statuses: `OK`; `BODY`; `NOENT`; `STATE` when the stay is not open; `DENY`
when the extension would carry the departure more than 90 days past arrival.

---

#### 0x15 `STAY_MOVE`

Moves an open stay to another guest room. The credentials the stay holds are
voided, because they are cut for the old room, and the stay's credential
count is reset. Writes a journal entry of kind 4 carrying the guest name.

Request body (6 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `handle` | Handle of an open stay. |
| 4 | u16 | `room_no` | Destination room, present in the lock map. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `handle` | Stay handle. |
| 5 | u16 | `room_no` | Room the stay now holds. |
| 7 | u16 | `voided` | Credentials voided by the move. |

Total response body: 9 bytes.

Statuses: `OK`; `BODY`; `NOENT`; `STATE` when the stay is not open, when the
destination room is not in the lock map, or when another open stay holds it.

---

#### 0x16 `OCCUPANCY`

Rolls occupancy up per zone. One row is returned for each zone in service,
in ascending zone order.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `count` | Rows that follow. |
| 2 + 7*i* | u8 | `zone` | Zone identifier. |
| 3 + 7*i* | u16 | `rooms` | Guest rooms the zone contains. |
| 5 + 7*i* | u16 | `occupied` | Rooms held by an open stay. |
| 7 + 7*i* | u16 | `guests` | Sum of the party sizes of those stays. |

Total response body: `2 + 7 * count` bytes.

Statuses: `OK`, `BODY`.

### 4.3 Credentials — 0x20 to 0x26

A credential is one encoded card. It carries an identifier, an owner (a stay
handle for a guest card, a staff reference for a staff card), the issue and
expiry times, the room it is cut for, the zone mask it opens, a class, a
sequence number and an 8-byte authentication blob. The blob is the value the
lock reads back from the card and is the value a PMS presents to
`CRED_VERIFY`.

Credential class values:

| Class | Meaning |
| --- | --- |
| 1 | Guest |
| 2 | Staff, general |
| 3 | Staff, supervisor |
| 4 | Staff, housekeeping |

Credential flag bits:

| Bit | Meaning |
| --- | --- |
| 0x01 | Active. |
| 0x02 | Voided. Set when the card is voided, reissued, or carried by a stay that is closed or moved. |

Three commands — `CRED_ISSUE`, `CRED_REISSUE` and `STAFF_CRED_ISSUE` — share
one response payload, the **encoding reply**:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `cred_id` | Identifier of the new credential. |
| 5 | bytes[8] | `blob` | Authentication blob written to the card. |
| 13 | u32 | `expires` | Expiry, service seconds. |
| 17 | u8 | `seq` | Encoding sequence number for this card position. |

Total: 18 bytes.

---

#### 0x20 `CRED_ISSUE`

Encodes a guest credential against an open stay. The credential inherits the
stay's room and departure time and is given the guest zone mask for that
room. Writes a journal entry of kind 5 carrying the supplied note.

Request body (5 + `note_len` bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `handle` | Handle of an open stay. |
| 4 | u8 | `note_len` | 0 to 96 |
| 5 | bytes[`note_len`] | `note` | Desk note recorded with the encoding. |

The body length must be exactly `5 + note_len`.

Response payload: the encoding reply, 18 bytes.

Statuses: `OK`; `BODY`; `NOENT`; `STATE` when the stay is not open; `FULL`
when the credential table has no free record.

---

#### 0x21 `CRED_REISSUE`

Replaces an active credential with a fresh encoding. The new credential
keeps the owner, room, zone mask, class and expiry of the old one, takes the
next sequence number, and the old credential is voided. Writes a journal
entry of kind 6 carrying the supplied note.

Request body (5 + `note_len` bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `cred_id` | An active credential. |
| 4 | u8 | `note_len` | 0 to 96 |
| 5 | bytes[`note_len`] | `note` | Desk note recorded with the reissue. |

Response payload: the encoding reply, 18 bytes.

Statuses: `OK`; `BODY`; `NOENT`; `STATE` when the credential is not active;
`FULL` when the credential table has no free record.

---

#### 0x22 `CRED_VOID`

Voids one credential. Writes a journal entry of kind 7.

Request body (4 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `cred_id` | An active credential. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `cred_id` | Credential voided. |
| 5 | u8 | `voided` | Credentials voided by this call. Always 1. |

Total response body: 6 bytes.

Statuses: `OK`; `BODY`; `NOENT`; `STATE` when the credential is already
inactive.

---

#### 0x23 `CRED_GET`

Reads one credential record, including the printed card number.

Request body (4 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `cred_id` | A credential. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `cred_id` | Credential identifier. |
| 5 | u32 | `owner` | Stay handle for a guest card; 40000 plus the staff identifier for a staff card. |
| 9 | u8 | `klass` | Credential class. |
| 10 | u8 | `flags` | Credential flag bits. |
| 11 | u8 | `seq` | Encoding sequence number. |
| 12 | u8 | reserved | Sent as 0. |
| 13 | u16 | `room_no` | Room the card is cut for; 0 for a staff card. |
| 15 | u16 | `zone_mask` | Zones the card opens. Bit *n* set means zone *n*+1. |
| 17 | u32 | `issued` | Issue time, service seconds. |
| 21 | u32 | `expires` | Expiry, service seconds. |
| 25 | bytes[8] | `blob` | Authentication blob. |
| 33 | u8 | `card_no_len` | Significant bytes of `card_no`, 0 to 20. |
| 34 | bytes[20] | `card_no` | Printed card number in the form `TKnnn-nnnn-nnnn-nnnn`, which fills the field. A shorter number is zero-padded. |

Total response body: 54 bytes.

Statuses: `OK`, `BODY`, `NOENT`.

---

#### 0x24 `CRED_LIST`

Pages through the credentials of one owner. Voided credentials are listed
alongside active ones.

Request body (6 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `owner` | Stay handle, or 40000 plus a staff identifier. |
| 4 | u8 | `first` | Index of the first matching credential to return, 0-based. |
| 5 | u8 | `count` | Rows to return, 0 to 64. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `returned` | Rows in this response. |
| 2 | u16 | `total` | Credentials the owner holds, ignoring `first` and `count`. |
| 4 + 10*i* | u32 | `cred_id` | Credential identifier. |
| 8 + 10*i* | u8 | `klass` | Credential class. |
| 9 + 10*i* | u8 | `flags` | Credential flag bits. |
| 10 + 10*i* | u32 | `expires` | Expiry, service seconds. |

Total response body: `4 + 10 * returned` bytes.

Statuses: `OK`; `BODY` when `count` is above 64.

---

#### 0x25 `CRED_VERIFY`

Asks the unit how a card would read at a named door, at a named time. The
command is a query: it opens nothing and alters no stay, credential, door
or zone record. Each refusal writes a journal entry of kind 8.

Request body (18 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `cred_id` | Credential identifier read from the card. |
| 4 | bytes[8] | `blob` | Authentication blob read from the card. |
| 12 | u16 | `door_id` | Door to test. Must be present in the lock map. |
| 14 | u32 | `at` | Time to test, service seconds. 0 means the current time. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `verdict` | 1 = the card opens the door, 0 = it does not. |
| 2 | u8 | `reason` | Refusal reason, 0 when `verdict` is 1. |
| 3 | u16 | `door_id` | Door tested. |
| 5 | u8 | `zone` | Zone the door belongs to. |
| 6 | u8 | reserved | Sent as 0. |

Total response body: 7 bytes.

Reason values, in the order the unit evaluates them:

| Reason | Journal wording | Meaning |
| --- | --- | --- |
| 0 | — | Granted. |
| 1 | reader tap declined | No credential holds that identifier. |
| 2 | card data mismatch | The blob does not match the credential's blob. |
| 3 | voided card presented | The credential is voided or otherwise not active. |
| 4 | expired card presented | `at` is past the credential's expiry. |
| 8 | lock offline at tap | The door is flagged offline. |
| 6 | zone in lockdown | The door's zone is in lockdown. |
| 5 | wrong floor tap | The zone is not in the card's zone mask and the door is not the card's own room. |
| 7 | outside access window | A guest card at a door whose zone is enforcing curfew, at a time inside the curfew; or a staff card outside the staff record's duty window. |

Statuses: `OK`; `BODY`; `NOENT` when the door is not in the lock map.

---

#### 0x26 `STAFF_CRED_ISSUE`

Encodes a staff credential against a staff record. The credential's zone
mask is the mask asked for, its class follows the staff class, and its
expiry is `days` whole days after issue. Writes a journal entry of kind 9
carrying the supplied note.

Request body (6 + `note_len` bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `staff_id` | An active staff record. |
| 2 | u16 | `zone_mask` | Zones to grant. Every bit set must also be set in the staff record's own mask. |
| 4 | u8 | `days` | 1 to 255 |
| 5 | u8 | `note_len` | 0 to 96 |
| 6 | bytes[`note_len`] | `note` | Desk note recorded with the encoding. |

The body length must be exactly `6 + note_len`.

Response payload: the encoding reply, 18 bytes.

Statuses: `OK`; `BODY`; `NOENT`; `STATE` when the staff record is not
active; `DENY` when `zone_mask` asks for a zone the staff record does not
hold; `FULL` when the credential table has no free record.

### 4.4 Lock map, zones, schedule and door export — 0x30 to 0x38

The lock map is the table of openings the site has provisioned. Each door
carries an identifier, the room it serves (0 for an opening that is not a
guest room), the zone it belongs to, service flags, a lock model and
firmware level, the time it was last heard from, a battery percentage, a
short label and a bus address.

Door flag bits:

| Bit | Meaning |
| --- | --- |
| 0x01 | In service. Set on every provisioned door. |
| 0x02 | Maintenance hold. |
| 0x04 | Common opening — an opening the site treats as public rather than as a guest room. |
| 0x08 | Reader offline. |
| 0x10 | Battery low. Reported by the lock; not settable from the control port. |
| 0x20 | Held-open alarm latched. |
| 0x40 | Lockdown hold, applied and released by `ZONE_LOCKDOWN`; not settable directly. |

Door model values:

| Model | Lock |
| --- | --- |
| 1 | TL-11 mortise lock |
| 2 | TL-14 escutcheon lock |
| 3 | TC-3 controller-backed opening |
| 4 | TL-20 lift reader |

Zone flag bits:

| Bit | Meaning |
| --- | --- |
| 0x01 | Zone in service. |
| 0x02 | Zone in lockdown. |
| 0x04 | Curfew enforced for guest cards. |

Schedule window modes:

| Mode | Action over the window |
| --- | --- |
| 1 | Unlock the zone. |
| 2 | Secure the zone. |
| 3 | Card required: the zone unlocks on the first valid card and secures at the end of the window. |

Day masks used by schedule windows and staff duty windows are 7-bit: bit
*n* selects day *n* of the local week. Bit 7 is reserved and must be 0.

---

#### 0x30 `DOOR_LIST`

Pages through the lock map in ascending door order.

Request body (3 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `first` | Index of the first provisioned door to return, 0-based. |
| 2 | u8 | `count` | Rows to return, 0 to 64. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `returned` | Rows in this response. |
| 2 | u16 | `total` | Doors provisioned, ignoring `first` and `count`. |
| 4 + 8*i* | u16 | `door_id` | Door identifier. |
| 6 + 8*i* | u16 | `room_no` | Room served, or 0. |
| 8 + 8*i* | u8 | `zone` | Zone, 1 to 32. |
| 9 + 8*i* | u8 | `flags` | Door flag bits. |
| 10 + 8*i* | u8 | `model` | Lock model. |
| 11 + 8*i* | u8 | `battery` | Battery, percent. |

Total response body: `4 + 8 * returned` bytes.

Statuses: `OK`; `BODY` when `count` is above 64.

---

#### 0x31 `DOOR_GET`

Reads one door record.

Request body (2 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `door_id` | A provisioned door. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `door_id` | Door identifier. |
| 3 | u16 | `room_no` | Room served, or 0. |
| 5 | u8 | `zone` | Zone. |
| 6 | u8 | `flags` | Door flag bits. |
| 7 | u8 | `model` | Lock model. |
| 8 | u8 | `fw` | Lock firmware level. |
| 9 | u32 | `last_seen` | Time the lock was last heard from, service seconds. |
| 13 | u8 | `battery` | Battery, percent. |
| 14 | u8 | `label_len` | Significant bytes of `label`, 0 to 10. |
| 15 | bytes[10] | `label` | Door label, zero-padded. |
| 25 | u8 | `bus_len` | Bytes of `bus` that follow, 0 to 8. |
| 26 | bytes[`bus_len`] | `bus` | Bus address of the lock, as raw bytes. |

Total response body: `26 + bus_len` bytes.

Statuses: `OK`, `BODY`, `NOENT`.

---

#### 0x32 `DOOR_SET_FLAGS`

Sets and clears service flags on one door. Bits are set first, then cleared,
so a bit named in both arguments ends clear. Writes a journal entry of kind
10.

Request body (4 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `door_id` | A provisioned door. |
| 2 | u8 | `set` | Bits to set. Only 0x02, 0x04, 0x08 and 0x20 may appear. |
| 3 | u8 | `clear` | Bits to clear. Only 0x02, 0x04, 0x08 and 0x20 may appear. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `door_id` | Door identifier. |
| 3 | u8 | `flags` | Door flag bits after the change. Bit 0x01 remains set. |

Total response body: 4 bytes.

Statuses: `OK`; `BODY` when a bit outside 0x2E appears in either argument;
`NOENT`.

---

#### 0x33 `ZONE_LIST`

Lists the zones that are in service, in ascending zone order.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `count` | Rows that follow. |
| 2 + 8*i* | u8 | `zone` | Zone identifier, 1 to 32. |
| 3 + 8*i* | u8 | `flags` | Zone flag bits. |
| 4 + 8*i* | u16 | `door_count` | Doors the zone contains. |
| 6 + 8*i* | u16 | `curfew_start` | Curfew start, minute of day. |
| 8 + 8*i* | u16 | `curfew_end` | Curfew end, minute of day. |

Total response body: `2 + 8 * count` bytes.

Statuses: `OK`, `BODY`.

---

#### 0x34 `ZONE_GET`

Reads one zone record.

Request body (1 byte):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `zone` | A zone in service, 1 to 32. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `zone` | Zone identifier. |
| 2 | u8 | `flags` | Zone flag bits. |
| 3 | u16 | `door_count` | Doors the zone contains. |
| 5 | u16 | `curfew_start` | Curfew start, minute of day. |
| 7 | u16 | `curfew_end` | Curfew end, minute of day. A curfew whose start and end are equal is not enforced. |
| 9 | u8 | `name_len` | Significant bytes of `name`, 0 to 24. |
| 10 | bytes[24] | `name` | Zone name, zero-padded. |

Total response body: 34 bytes.

Statuses: `OK`, `BODY`, `NOENT`.

---

#### 0x35 `ZONE_LOCKDOWN`

Places a zone into or out of lockdown. The lockdown hold is applied to or
released from every door in the zone. Writes a journal entry of kind 11
carrying the zone name.

Request body (2 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `zone` | A zone in service. |
| 1 | u8 | `on` | 1 to apply lockdown, 0 to release it. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `zone` | Zone identifier. |
| 2 | u8 | `flags` | Zone flag bits after the change. |
| 3 | u16 | `doors` | Doors the change touched. |

Total response body: 5 bytes.

Statuses: `OK`; `BODY` when `on` is above 1; `NOENT`.

---

#### 0x36 `SCHED_LIST`

Lists the schedule windows in use, in ascending window order.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `count` | Rows that follow. |
| 2 + 12*i* | u8 | `window_id` | Window identifier, 1 to 64. |
| 3 + 12*i* | u8 | `zone` | Zone the window acts on. |
| 4 + 12*i* | u8 | `mode` | Window mode, 1 to 3. |
| 5 + 12*i* | u8 | `days` | Day mask, bits 0 to 6. |
| 6 + 12*i* | u16 | `start_min` | Window start, minute of day. |
| 8 + 12*i* | u16 | `end_min` | Window end, minute of day. A window whose end is below its start runs across midnight. |
| 10 + 12*i* | u32 | `hits` | Cumulative count of openings the window has governed. |

Total response body: `2 + 12 * count` bytes.

Statuses: `OK`, `BODY`.

---

#### 0x37 `SCHED_SET`

Creates or overwrites a schedule window. Writes a journal entry of kind 12.

Request body (8 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `window_id` | 0 to allocate the next free window, or 1 to 64 to write that window. |
| 1 | u8 | `zone` | A zone in service. |
| 2 | u8 | `mode` | 1 to 3 |
| 3 | u8 | `days` | Day mask, bits 0 to 6. Bit 7 must be 0. |
| 4 | u16 | `start_min` | 0 to 1439 |
| 6 | u16 | `end_min` | 0 to 1439, and not equal to `start_min`. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | bytes[12] | window | The written window, in the same 12-byte layout `SCHED_LIST` uses for a row. |

Total response body: 13 bytes.

Statuses: `OK`; `BODY`; `NOENT` when the zone is not in service; `FULL` when
`window_id` is 0 and no window is free.

---

#### 0x38 `DOOR_EXPORT`

Renders a batch of door records into the PMS import region as import text,
and reports how many were rendered. The rendered text is read out with
`EXPORT_FETCH` (0x55) and the batch is reported by `EXPORT_STAT` (0x56).
Section 6.2 specifies the line grammar; section 7 specifies the batch
lifecycle.

Request body (1 + 2 × `count` bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `count` | Doors requested, 0 to 128. |
| 1 + 2*i* | u16 | `door_id` | Door to render. |

The body length must be exactly `1 + 2 * count`.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `rendered` | Doors rendered into the batch. |
| 3 | u16 | `skipped` | `count` minus `rendered`. |

Total response body: 5 bytes.

Statuses: `OK`; `BODY` when `count` is above 128 or the body length does not
match `count`.

### 4.5 Staff — 0x40 to 0x42

A staff record carries an identifier, a staff class, flag bits, a duty
window (a day mask and a start and end minute of day), the zone mask the
member may be granted, a count of the credentials issued to them, and a
name.

Staff class values:

| Class | Role |
| --- | --- |
| 1 | General staff |
| 2 | Housekeeping |
| 3 | Front desk |
| 4 | Duty manager |
| 5 | Engineering |

Staff flag bits:

| Bit | Meaning |
| --- | --- |
| 0x01 | Record active. |

---

#### 0x40 `STAFF_LIST`

Pages through the staff table in table order.

Request body (2 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `first` | Index of the first staff record to return, 0-based. |
| 1 | u8 | `count` | Rows to return, 0 to 64. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `returned` | Rows in this response. |
| 2 | u8 | `total` | Staff records held, ignoring `first` and `count`. |
| 3 + 6*i* | u16 | `staff_id` | Staff identifier. |
| 5 + 6*i* | u8 | `klass` | Staff class. |
| 6 + 6*i* | u8 | `flags` | Staff flag bits. |
| 7 + 6*i* | u16 | `zone_mask` | Zones the member may be granted. Bit *n* set means zone *n*+1. |

Total response body: `3 + 6 * returned` bytes.

Statuses: `OK`; `BODY` when `count` is above 64.

---

#### 0x41 `STAFF_GET`

Reads one staff record.

Request body (2 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `staff_id` | A staff record. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `staff_id` | Staff identifier. |
| 3 | u8 | `klass` | Staff class. |
| 4 | u8 | `flags` | Staff flag bits. |
| 5 | u8 | `days` | Duty day mask, bits 0 to 6. |
| 6 | u8 | reserved | Sent as 0. |
| 7 | u16 | `start_min` | Duty window start, minute of day. |
| 9 | u16 | `end_min` | Duty window end, minute of day. An end below the start runs across midnight. |
| 11 | u16 | `zone_mask` | Zones the member may be granted. |
| 13 | u32 | `cred_count` | Credentials issued to the member. |
| 17 | u8 | `name_len` | Significant bytes of `name`, 0 to 48. |
| 18 | bytes[48] | `name` | Staff name, zero-padded. |

Total response body: 66 bytes.

Statuses: `OK`, `BODY`, `NOENT`.

---

#### 0x42 `STAFF_SET_WINDOW`

Sets the duty window of one staff record. The window governs when staff
credentials owned by that record are honoured.

Request body (7 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `staff_id` | A staff record. |
| 2 | u8 | `days` | Day mask, bits 0 to 6. Bit 7 must be 0. |
| 3 | u16 | `start_min` | 0 to 1439 |
| 5 | u16 | `end_min` | 0 to 1439, and not equal to `start_min`. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `staff_id` | Staff identifier. |
| 3 | u8 | `days` | Day mask after the change. |
| 4 | u16 | `start_min` | Window start after the change. |
| 6 | u16 | `end_min` | Window end after the change. |

Total response body: 8 bytes.

Statuses: `OK`, `BODY`, `NOENT`.

### 4.6 Journal and export — 0x50 to 0x56

The journal is the unit's event record. Every entry carries an identifier, a
timestamp in service seconds, a kind, an actor, a room, a subject and a free
text field. The identifier is the value `JRNL_GET` (0x51), `JRNL_PEEK`
(0x53) and `EXPORT_BEGIN` (0x54) take.

Journal kinds:

| Kind | Event | `subject` | Text field |
| --- | --- | --- | --- |
| 1 | Stay opened | Stay handle | Guest name |
| 2 | Stay closed | Stay handle | Guest name |
| 3 | Stay extended | Stay handle | Guest name |
| 4 | Stay moved | Stay handle | Guest name |
| 5 | Guest credential issued | Credential identifier | Desk note |
| 6 | Guest credential reissued | Credential identifier | Desk note |
| 7 | Credential voided | Credential identifier | Service note |
| 8 | Access refused | Credential identifier, or 0 | Refusal wording |
| 9 | Staff credential issued | Credential identifier | Desk note |
| 10 | Door flags changed | Door identifier | Service note |
| 11 | Zone lockdown changed | Zone identifier | Zone name |
| 12 | Schedule window set | Window identifier | Service note |
| 13 | Clock settings changed | Time offset applied | Service note |
| 14 | Self-test run | 0 | Service note |

`actor` is the low byte of the staff identifier that carried out the event,
or 0 when the desk itself did. `room_no` is the room the event concerns, or
0 where the event is not room-specific.

---

#### 0x50 `JRNL_COUNT`

Reports the depth of the journal and the range of identifiers it holds.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `count` | Entries held. |
| 3 | u16 | `oldest_id` | Lowest identifier held, or 0 when the journal is empty. |
| 5 | u16 | `newest_id` | Highest identifier held, or 0 when the journal is empty. |

Total response body: 7 bytes.

Statuses: `OK`, `BODY`.

---

#### 0x51 `JRNL_GET`

Reads one journal entry.

Request body (4 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `entry_id` | A journal entry identifier. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u32 | `entry_id` | Journal entry identifier. |
| 5 | u32 | `ts` | Time of the event, service seconds. |
| 9 | u8 | `kind` | Journal kind, 1 to 14. |
| 10 | u8 | `actor` | Acting staff identifier, low byte, or 0. |
| 11 | u16 | `room_no` | Room concerned, or 0. |
| 13 | u32 | `subject` | Identifier of the record the entry concerns. |
| 17 | u8 | `text_len` | Bytes of `text` that follow, 0 to 96. |
| 18 | bytes[`text_len`] | `text` | Text field for the kind, as raw bytes. |

Total response body: `18 + text_len` bytes.

Statuses: `OK`, `BODY`, `NOENT`.

---

#### 0x52 `JRNL_FIND`

Selects journal entry identifiers by kind, room and time span. The response
carries identifiers only; `JRNL_GET` reads the entries themselves.

Request body (12 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `kind` | 0 for any kind, or 1 to 14 for that kind. |
| 1 | u16 | `room_no` | 0 for any room, or a room number. |
| 3 | u32 | `ts_from` | Earliest timestamp to accept, service seconds. |
| 7 | u32 | `ts_to` | Latest timestamp to accept. 0 means no upper bound. |
| 11 | u8 | `limit` | Identifiers to return, 0 to 128. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u8 | `returned` | Identifiers that follow. |
| 2 + 4*i* | u32 | `entry_id` | Matching journal entry identifier. |

Total response body: `2 + 4 * returned` bytes.

Statuses: `OK`; `BODY` when `kind` is above 14 or `limit` is above 128.

---

#### 0x53 `JRNL_PEEK`

Renders one journal entry in the peek form: the same fixed fields the
journal import line carries, followed by the text field in hexadecimal.
Section 6.3 specifies the peek grammar. `JRNL_PEEK` reads a single entry and
does not touch the batch region.

Request body (4 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u32 | `entry_id` | A journal entry identifier. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `len` | Bytes of `line` that follow. |
| 3 | bytes[`len`] | `line` | The rendered line, printable ASCII, with no trailing newline. |

Statuses: `OK`, `BODY`, `NOENT`.

---

#### 0x54 `EXPORT_BEGIN`

Renders a batch of journal entries into the PMS import region as import
text, and reports how many were rendered. The rendered text is read out with
`EXPORT_FETCH` (0x55) and the batch is reported by `EXPORT_STAT` (0x56).
Section 6.1 specifies the line grammar; section 7 specifies the batch
lifecycle.

Request body (1 + 4 × `count` bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u8 | `count` | Entries requested, 0 to 128. |
| 1 + 4*i* | u32 | `entry_id` | Journal entry to render. |

The body length must be exactly `1 + 4 * count`.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `rendered` | Entries rendered into the batch. |
| 3 | u16 | `skipped` | `count` minus `rendered`. |

Total response body: 5 bytes.

Statuses: `OK`; `BODY` when `count` is above 128 or the body length does not
match `count`.

---

#### 0x55 `EXPORT_FETCH`

Returns the next slice of the current batch's import text.

Request body (2 bytes):

| Offset | Width | Field | Permitted range |
| --- | --- | --- | --- |
| 0 | u16 | `want` | Bytes the caller would like. |

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `len` | Bytes of `data` that follow. |
| 3 | bytes[`len`] | `data` | Import text, continuing from where the previous fetch stopped. |

`len` may be smaller than `want`: the unit returns what remains of the batch
and never more than the port's maximum fetch size. A caller reads `len`, not
`want`. When the batch has been read out in full, further fetches return
`len` = 0.

Total response body: `3 + len` bytes.

Statuses: `OK`, `BODY`.

---

#### 0x56 `EXPORT_STAT`

Reports the counters of the current batch.

Request body: empty.

Response payload:

| Offset | Width | Field | Meaning |
| --- | --- | --- | --- |
| 0 | u8 | status | |
| 1 | u16 | `rendered` | Records rendered into the current batch. |
| 3 | u16 | `skipped` | Records requested but not rendered. |
| 5 | u16 | `remaining` | Rendered records whose line has not yet been fetched in full. |
| 7 | u32 | `batch_seq` | Batch sequence number, incremented each time a batch is begun. |

Total response body: 11 bytes.

Statuses: `OK`, `BODY`.

## 5. Data model

The control port exposes seven record types. Doors, zones, schedule windows
and staff are site configuration, loaded when the unit starts. Stays,
credentials and journal entries are operating records, created as the desk
works.

### 5.1 Doors

A **door** is one provisioned opening. It is identified by `door_id`, which
is dense and stable for the site. `room_no` names the guest room the door
serves; an opening that is not a guest room carries `room_no` 0. Every door
belongs to exactly one **zone**, named by `zone`. The door also carries the
lock model and firmware level, the last time the lock was heard from, a
battery percentage, a ten-character label and a bus address of up to eight
bytes.

A room number appears on at most one door. `STAY_OPEN` and `STAY_MOVE`
resolve a room number to a door through that relation, and refuse a room
that no door serves.

### 5.2 Zones

A **zone** groups doors for schedule, curfew and lockdown purposes. It is
identified by `zone`, 1 to 32, and carries flag bits, the number of doors it
contains, a curfew window and a name. A zone that is not in service is not
listed by `ZONE_LIST` and is not accepted by `ZONE_GET`, `ZONE_LOCKDOWN` or
`SCHED_SET`.

Lockdown is a zone-level state that is mirrored onto the zone's doors: when
a zone enters lockdown every door in it takes the lockdown hold flag, and
when the zone leaves lockdown the hold is released.

### 5.3 Schedule windows

A **schedule window** binds a zone to a mode over a range of minutes on a
set of days. Windows are identified by `window_id`, 1 to 64. Several windows
may name the same zone; a site typically pairs an unlock window with a
secure window covering the rest of the day. Each window carries a cumulative
`hits` count of the openings it has governed.

### 5.4 Staff

A **staff** record is a person the site may issue staff cards to. It carries
a class, active flag, a duty window and the zone mask the member may be
granted. `STAFF_CRED_ISSUE` will not grant a zone the record does not hold,
and `CRED_VERIFY` refuses a staff card presented outside the record's duty
window. `cred_count` counts the staff credentials issued to the member.

### 5.5 Stays

A **stay** is one room occupancy. It is identified by `handle` and carries a
room, party size, arrival, departure, guest name and credential count.
`state` is 1 while the stay is open and 2 once it is closed. At most one
open stay may hold a given room at a time; a closed stay does not hold its
room.

A stay owns the guest credentials issued against it. Closing or moving a
stay voids them.

### 5.6 Credentials

A **credential** is one encoded card. `owner` links it to the record that
holds it: a stay handle for a guest card, or 40000 plus a staff identifier
for a staff card. `CRED_LIST` takes that same `owner` value, so the two
kinds of card are listed the same way.

A guest credential takes its room and expiry from the stay, and the guest
zone mask for that room. A staff credential carries no room, takes the zone mask asked for at issue,
and expires a whole number of days after issue.

`seq` counts encodings of the same card position: a card issued fresh has
`seq` 1, and each reissue takes the next value. `blob` is the value the lock
reads back from the card, and is what `CRED_VERIFY` compares against.

### 5.7 Journal entries

A **journal entry** records one event. Entries carry an identifier, a
timestamp, a kind, an actor, a room, a subject and a text field. Section 4.6
lists the kinds together with what `subject` and the text field hold for
each.

The journal is a ring of fixed depth. Once it is full, writing a new entry
replaces the oldest one, and the identifier of the replaced entry stops
resolving.

## 6. PMS import text

The unit renders records into line-oriented import text for bulk loading
into a PMS. Two renderers exist: the journal renderer, driven by
`EXPORT_BEGIN` (0x54), and the door renderer, driven by `DOOR_EXPORT`
(0x38). Both write into the same batch region and are read back with
`EXPORT_FETCH` (0x55).

Both renderers produce the same overall shape: a set of comma-separated
fixed fields, followed by the variable field or fields, which run to the end
of the line. Records are separated by a single LF (`0x0A`); the batch has no
trailing newline. Each renderer applies its own escaping to its variable
fields so that an importer can split on commas and on LF without ambiguity,
and can recover the original bytes exactly.

The escaping in the two renderers is different. An importer must know which
renderer produced a batch before it parses it.

### 6.1 Journal import lines

Grammar:

```
<entry_id> "," <kind> "," <room_no> "," <subject> "," <text>
```

| Field | Form | Source |
| --- | --- | --- |
| `entry_id` | Unsigned decimal | Journal entry identifier |
| `kind` | Unsigned decimal | Journal kind, 1 to 14 |
| `room_no` | Unsigned decimal | Room concerned, or 0 |
| `subject` | Unsigned decimal | Subject identifier for the kind |
| `text` | Escaped, runs to end of line | The entry's text field |

The four fixed fields are plain decimal and contain no separators. The fifth
field is the text field, escaped as follows, byte by byte:

| Input byte | Rendered as |
| --- | --- |
| `"` (0x22) | `\"` — a backslash followed by a double quote |
| `\` (0x5C) | `\\` — two backslashes |
| Any other byte in the range 0x20 to 0x7E | The byte itself |
| Any other byte | `\` followed by exactly three decimal digits giving the byte value, zero-padded — for example `\009`, `\195` |

An importer reverses the escaping by scanning for a backslash: a backslash
followed by `"` or `\` yields that character, and a backslash followed by
three digits yields the byte of that value. Every other byte stands for
itself. The escaping is total: no unescaped `"` , `\`, LF or non-printable
byte can appear in the text field.

**Worked example.** A journal entry with identifier 386, kind 5, room 101,
subject 4240, whose text field holds the 24 bytes

```
say "hi" \ path<09>tab<C3><A9>end
```

renders as the line

```
386,5,101,4240,say \"hi\" \\ path\009tab\195\169end
```

### 6.2 Door import lines

Grammar:

```
<door_id> "," <zone> "," <room_no> "," <flags> "," <label> "," <bus>
```

| Field | Form | Source |
| --- | --- | --- |
| `door_id` | Unsigned decimal | Door identifier |
| `zone` | Unsigned decimal | Zone the door belongs to |
| `room_no` | Unsigned decimal | Room served, or 0 |
| `flags` | Unsigned decimal | Door flag bits, as a decimal number |
| `label` | Escaped | The door label, up to its significant length |
| `bus` | Escaped, runs to end of line | The bus address bytes |

The four fixed fields are plain decimal and contain no separators. The
`label` and `bus` fields are both escaped, byte by byte, as follows:

| Input byte | Rendered as |
| --- | --- |
| Any byte in the range 0x20 to 0x7E except `%` (0x25) | The byte itself |
| `%` (0x25), and every byte outside 0x20 to 0x7E | `%` followed by exactly two uppercase hexadecimal digits giving the byte value — for example `%00`, `%ED`, `%25` |

The comma between `label` and `bus` is a separator written by the renderer
and is not part of either field.

An importer reverses the escaping by scanning for `%`: a `%` and the two
hexadecimal digits after it yield the byte of that value, and every other
byte stands for itself.

**Worked example.** Door 1 in zone 1, serving no guest room, with flags
0x05, label `LOBBY MAIN`, and the seven bus bytes
`06 70 10 46 02 51 ED`, renders as the line

```
1,1,0,5,LOBBY MAIN,%06p%10F%02Q%ED
```

The bus bytes 0x70, 0x46 and 0x51 are printable and appear as `p`, `F` and
`Q`; the remaining four are escaped.

### 6.3 The peek line

`JRNL_PEEK` (0x53) renders one journal entry on its own, outside the batch
region, in a form intended for a service terminal rather than for import.
It uses the same four fixed decimal fields as the journal import line and
then renders the text field as uppercase hexadecimal, two digits per byte,
with no separators and no escaping:

```
<entry_id> "," <kind> "," <room_no> "," <subject> "," <hex of text>
```

For the entry used in the section 6.1 example, `JRNL_PEEK` returns

```
386,5,101,4240,7361792022686922205C207061746809746162C3A9656E64
```

## 7. Operational notes

### 7.1 Batch lifecycle

The two export renderers share one batch. A batch has three phases:

1. **Begin.** `EXPORT_BEGIN` (0x54) renders a list of journal entries, or
   `DOOR_EXPORT` (0x38) renders a list of doors. Either command discards the
   previous batch, renders the new one, resets the read position to the
   start of the rendered text, and increments `batch_seq`.
2. **Fetch.** `EXPORT_FETCH` (0x55) reads the rendered text out in order,
   advancing a read position as it goes. Fetching does not change
   `rendered`, `skipped` or `batch_seq`.
3. **Status.** `EXPORT_STAT` (0x56) reports the counters of the current
   batch at any point, before or during the fetch.

Because there is one batch, a session that needs both a journal batch and a
door batch must fetch the first in full before beginning the second.

### 7.2 Counters

* `rendered` — records written into the batch.
* `skipped` — records requested but not written: `count` minus `rendered`.
  Both the begin commands report the same pair in their own response, and
  `EXPORT_STAT` repeats them for as long as the batch stands.
* `remaining` — rendered records whose line has not yet been fetched in
  full. It falls as the caller fetches and reaches 0 when the batch has been
  read out.
* `batch_seq` — a counter of batches begun on this session. A PMS can hold
  it across a fetch loop and compare it to detect that a batch was replaced.

A record is skipped when the identifier names no record, and when the record
does not fit the batch. A batch is bounded in total rendered size; records
requested beyond that bound are not rendered and are counted in `skipped`.

### 7.3 Fetching to the end of a batch

`EXPORT_FETCH` returns what remains of the batch, never more than `want` and
never more than the port's maximum fetch size, so a caller loops:

```
begin the batch
loop:
    data = EXPORT_FETCH(want)
    if len(data) == 0: stop
    append data to the import file
```

A fetch on an exhausted batch returns `OK` with `len` = 0 and no data; that
is the normal end of the loop, not an error. A fetch before any batch has
been begun likewise returns `OK` with `len` = 0.

Import text may be split across fetches at any byte, including inside a
line or inside an escape sequence. A caller should concatenate all fetched
data before splitting it into lines.

### 7.4 Ordering guarantees

* `EXPORT_BEGIN` and `DOOR_EXPORT` render records in the order the
  identifiers appear in the request, and `EXPORT_FETCH` returns the text in
  that order. Duplicated identifiers render twice.
* Rendering stops at the first requested record that does not fit the batch;
  every record after it in the request is counted in `skipped`. Identifiers
  that name no record are passed over and rendering continues with the next
  identifier.
* `DOOR_LIST` returns doors in ascending `door_id` order. `ZONE_LIST`,
  `SCHED_LIST` and `OCCUPANCY` return rows in ascending identifier order.
* `STAY_LIST`, `CRED_LIST` and `STAFF_LIST` return rows in table order,
  which is the order in which the records were allocated.
* `JRNL_FIND` returns identifiers in journal storage order. That is
  ascending identifier order for the entries the unit loaded at start;
  entries written during a session take the slots of the oldest entries and
  therefore appear before them. A PMS that needs chronological order should
  sort the entries it reads on `ts`.
* `total` in a list response counts every matching record, independent of
  `first` and `count`, so a caller can size a paging loop from the first
  response.

### 7.5 Paging

The list commands take a 0-based `first` and a row `count`. To walk a table,
issue the first call with `first` = 0, read `total`, and repeat with `first`
advanced by `returned` until `first` reaches `total`. A `count` of 0 is
accepted and returns a header with no rows, which is a cheap way to read
`total` alone.

### 7.6 Journal timestamps

Journal entries carry `ts` in service seconds. Entries written by the
commands in this guide are stamped at the moment the command runs, so a
`JRNL_FIND` spanning `ts_from` to `ts_to` selects on the unit's own time
base rather than on calendar time. `CLOCK_GET` reports both time bases, so a
PMS can hold the offset between them and convert.

## 8. Appendix — worked byte dumps

The captures below are complete frames, header and body, taken from a TK-220
running firmware 3.12.7 at a commissioned site. Values that depend on the
unit, the site or the moment of capture — uptime, timestamps, names — differ
on other units.

### A.1 `HELLO` (0x01) — device group

```
->  4B 58 30 31 01 00 00 00
<-  4B 58 30 31 01 01 15 00
    00 DC 00 04 00 0C 00 04 7A 51 00 68 03 00 00 1E
    00 00 00 FF 01
```

Status `OK`; `model` 220 (`DC 00`); `hw_rev` 4; `protocol` 12; `build`
`00517A04`; `uptime` 872 s; `stays_open` 30; `caps` `01FF`.

### A.2 `STAY_LIST` (0x13) — stays group

```
->  4B 58 30 31 13 00 02 00
    00 02
<-  4B 58 30 31 13 01 13 00
    00 02 34 01 00 00 00 24 03 01 01 02 00 00 00 67
    02 01 01
```

Request: `first` 0, `count` 2. Status `OK`; `returned` 2; `total` 52. Row 0:
`handle` 1, `room_no` 804, `state` 1, `party` 1. Row 1: `handle` 2,
`room_no` 615, `state` 1, `party` 1.

### A.3 `CRED_GET` (0x23) — credentials group

```
->  4B 58 30 31 23 00 04 00
    1A 10 00 00
<-  4B 58 30 31 23 01 36 00
    00 1A 10 00 00 01 00 00 00 01 01 01 00 24 03 89
    00 9B A0 DA 05 A7 B1 E8 05 B3 B8 1F 73 20 9A 24
    96 14 54 4B 36 35 32 2D 34 31 32 32 2D 30 38 30
    34 2D 35 39 31 31
```

Request: `cred_id` 4122. Status `OK`; `cred_id` 4122; `owner` 1 (stay handle
1); `klass` 1 (guest); `flags` `01` (active); `seq` 1; `room_no` 804;
`zone_mask` `0089` (zones 1, 4 and 8); `issued` 98066587; `expires`
99135911; `blob` `B3 B8 1F 73 20 9A 24 96`; `card_no_len` 20; `card_no`
`TK652-4122-0804-5911`.

### A.4 `ZONE_GET` (0x34) — lock map group

```
->  4B 58 30 31 34 00 01 00
    07
<-  4B 58 30 31 34 01 22 00
    00 07 01 16 00 00 00 9F 05 08 43 41 52 20 50 41
    52 4B 00 00 00 00 00 00 00 00 00 00 00 00 00 00
    00 00
```

Request: `zone` 7. Status `OK`; `zone` 7; `flags` `01` (in service);
`door_count` 22; `curfew_start` 0; `curfew_end` 1439; `name_len` 8; `name`
`CAR PARK`.

### A.5 `STAFF_GET` (0x41) — staff group

```
->  4B 58 30 31 41 00 02 00
    03 00
<-  4B 58 30 31 41 01 42 00
    00 03 00 03 01 1F 00 48 03 9F 05 FF 01 01 00 00
    00 0A 54 20 42 52 45 4E 4E 41 47 48 00 00 00 00
    00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
    00 00 00 00 00 00 00 00 00 00 00 00 00 00
```

Request: `staff_id` 3. Status `OK`; `staff_id` 3; `klass` 3 (front desk);
`flags` `01` (active); `days` `1F` (days 0 to 4); `start_min` 840 (14:00);
`end_min` 1439 (23:59); `zone_mask` `01FF` (zones 1 to 9); `cred_count` 1;
`name_len` 10; `name` `T BRENNAGH`.

### A.6 `JRNL_GET` (0x51) — journal group

```
->  4B 58 30 31 51 00 04 00
    07 00 00 00
<-  4B 58 30 31 51 01 1D 00
    00 07 00 00 00 2A 67 DF 05 02 12 6A 02 25 00 00
    00 0B 45 54 48 45 52 49 4E 47 54 4F 4E
```

Request: `entry_id` 7. Status `OK`; `entry_id` 7; `ts` 98252586; `kind` 2
(stay closed); `actor` 18; `room_no` 618; `subject` 37 (the stay handle);
`text_len` 11; `text` `ETHERINGTON`.
