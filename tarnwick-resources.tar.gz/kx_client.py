#!/usr/bin/env python3
"""
Tarnwick Systems TK-220 -- KX01 control port sample client.

Part of the TK-220 PMS integration kit.  Standard library only.

Usage:

    from kx_client import KX

    with KX("127.0.0.1", 1337) as kx:
        print(kx.hello())
        print(kx.door_get(1))

Every helper below corresponds to one KX01 opcode and uses the same field
names as the TK-220 KX01 Integration Guide.  Helpers return a dict (or a
list of dicts for the list commands) on status OK, and raise KXStatus
otherwise.

Run this file directly for a short demo against a unit:

    python3 kx_client.py 127.0.0.1 1337
"""

import socket
import struct
import sys

MAGIC = b"KX01"
RESP_BIT = 0x01
HDR_LEN = 8
BODY_MAX = 4096

# Status byte values, as listed in the guide.
ST_OK = 0x00
ST_FRAME = 0x01
ST_OPCODE = 0x02
ST_BODY = 0x03
ST_FULL = 0x04
ST_NOENT = 0x05
ST_STATE = 0x06
ST_DENY = 0x07

STATUS_NAME = {
    ST_OK: "OK",
    ST_FRAME: "FRAME",
    ST_OPCODE: "OPCODE",
    ST_BODY: "BODY",
    ST_FULL: "FULL",
    ST_NOENT: "NOENT",
    ST_STATE: "STATE",
    ST_DENY: "DENY",
}

# Opcodes.
OP_HELLO = 0x01
OP_DEVINFO = 0x02
OP_CLOCK_GET = 0x03
OP_CLOCK_SET = 0x04
OP_DIAG_SELFTEST = 0x05
OP_DIAG_TEXT = 0x06
OP_COUNTERS = 0x07
OP_SITE_INFO = 0x08

OP_STAY_OPEN = 0x10
OP_STAY_CLOSE = 0x11
OP_STAY_GET = 0x12
OP_STAY_LIST = 0x13
OP_STAY_EXTEND = 0x14
OP_STAY_MOVE = 0x15
OP_OCCUPANCY = 0x16

OP_CRED_ISSUE = 0x20
OP_CRED_REISSUE = 0x21
OP_CRED_VOID = 0x22
OP_CRED_GET = 0x23
OP_CRED_LIST = 0x24
OP_CRED_VERIFY = 0x25
OP_STAFF_CRED_ISSUE = 0x26

OP_DOOR_LIST = 0x30
OP_DOOR_GET = 0x31
OP_DOOR_SET_FLAGS = 0x32
OP_ZONE_LIST = 0x33
OP_ZONE_GET = 0x34
OP_ZONE_LOCKDOWN = 0x35
OP_SCHED_LIST = 0x36
OP_SCHED_SET = 0x37
OP_DOOR_EXPORT = 0x38

OP_STAFF_LIST = 0x40
OP_STAFF_GET = 0x41
OP_STAFF_SET_WINDOW = 0x42

OP_JRNL_COUNT = 0x50
OP_JRNL_GET = 0x51
OP_JRNL_FIND = 0x52
OP_JRNL_PEEK = 0x53
OP_EXPORT_BEGIN = 0x54
OP_EXPORT_FETCH = 0x55
OP_EXPORT_STAT = 0x56


class KXError(Exception):
    """Transport or framing problem."""


class KXStatus(Exception):
    """The unit answered with a status other than OK."""

    def __init__(self, opcode, status):
        self.opcode = opcode
        self.status = status
        name = STATUS_NAME.get(status, "0x%02x" % status)
        super().__init__("opcode 0x%02x returned %s" % (opcode, name))


def _cstr(raw):
    """Decode a fixed-width text field, dropping the trailing padding."""
    return raw.split(b"\x00", 1)[0].decode("latin-1")


class KX:
    """One KX01 session.  A session is one TCP connection."""

    def __init__(self, host="127.0.0.1", port=1337, timeout=10.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.sock = None

    # ---- connection ----

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port),
                                             timeout=self.timeout)
        self.sock.settimeout(self.timeout)
        return self

    def close(self):
        if self.sock is not None:
            try:
                self.sock.close()
            finally:
                self.sock = None

    def __enter__(self):
        return self.connect()

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    # ---- framing ----

    def _recv_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise KXError("connection closed by the unit")
            buf += chunk
        return buf

    def request(self, opcode, body=b""):
        """Send one command frame and return (status, payload).

        payload is the response body with the leading status byte removed.
        """
        if self.sock is None:
            self.connect()
        if len(body) > BODY_MAX:
            raise KXError("request body too long")
        hdr = MAGIC + bytes([opcode, 0x00]) + struct.pack("<H", len(body))
        self.sock.sendall(hdr + body)

        rhdr = self._recv_exact(HDR_LEN)
        if rhdr[0:4] != MAGIC:
            raise KXError("bad response magic")
        if rhdr[4] != opcode:
            raise KXError("response opcode mismatch")
        if not rhdr[5] & RESP_BIT:
            raise KXError("response bit not set")
        rlen = struct.unpack_from("<H", rhdr, 6)[0]
        rbody = self._recv_exact(rlen) if rlen else b""
        if not rbody:
            raise KXError("empty response body")
        return rbody[0], rbody[1:]

    def call(self, opcode, body=b""):
        """As request(), but raise KXStatus when the status is not OK."""
        status, payload = self.request(opcode, body)
        if status != ST_OK:
            raise KXStatus(opcode, status)
        return payload

    # ---- device, site, clock, counters, diagnostics ----

    def hello(self):
        """0x01 -- greet the unit and read its identity summary."""
        p = self.call(OP_HELLO)
        model, hw_rev, protocol = struct.unpack_from("<HHH", p, 0)
        build, uptime, stays_open = struct.unpack_from("<III", p, 6)
        caps = struct.unpack_from("<H", p, 18)[0]
        return {
            "model": model,
            "hw_rev": hw_rev,
            "protocol": protocol,
            "build": build,
            "uptime": uptime,
            "stays_open": stays_open,
            "caps": caps,
        }

    def devinfo(self):
        """0x02 -- read the full device record."""
        p = self.call(OP_DEVINFO)
        return {
            "serial": _cstr(p[0:16]),
            "mac": ":".join("%02X" % b for b in p[16:22]),
            "fw_major": p[22],
            "fw_minor": p[23],
            "fw_patch": p[24],
            "hw_rev": p[25],
            "build": struct.unpack_from("<I", p, 26)[0],
            "service_offset": struct.unpack_from("<I", p, 30)[0],
            "caps": struct.unpack_from("<H", p, 34)[0],
            "reserved": struct.unpack_from("<H", p, 36)[0],
        }

    @staticmethod
    def _clock(p):
        return {
            "device_seconds": struct.unpack_from("<I", p, 0)[0],
            "host_seconds": struct.unpack_from("<I", p, 4)[0],
            "tz_min": struct.unpack_from("<h", p, 8)[0],
            "dst": p[10],
            "drift_ppm": struct.unpack_from("<b", p, 11)[0],
            "sync_age": struct.unpack_from("<I", p, 12)[0],
        }

    def clock_get(self):
        """0x03 -- read the clock block."""
        return self._clock(self.call(OP_CLOCK_GET))

    def clock_set(self, tz_min, dst):
        """0x04 -- set the timezone offset in minutes and the DST flag."""
        body = struct.pack("<hB", tz_min, dst)
        return self._clock(self.call(OP_CLOCK_SET, body))

    def diag_selftest(self):
        """0x05 -- run the self-test and return one entry per test."""
        p = self.call(OP_DIAG_SELFTEST)
        count = p[0]
        out = []
        for i in range(count):
            test_no, result = p[1 + 4 * i], p[2 + 4 * i]
            detail = struct.unpack_from("<H", p, 3 + 4 * i)[0]
            out.append({"test_no": test_no, "result": result,
                        "detail": detail})
        return out

    def diag_text(self):
        """0x06 -- read the human-readable diagnostic page."""
        p = self.call(OP_DIAG_TEXT)
        n = struct.unpack_from("<H", p, 0)[0]
        return p[2:2 + n].decode("latin-1")

    COUNTER_NAMES = (
        "uptime", "device_seconds", "cards_encoded", "cards_voided",
        "head_cycles", "head_faults", "mains_events", "reader_resets",
        "reader_temp", "doors_provisioned", "doors_online", "doors_offline",
        "doors_lowbatt", "zones_in_service", "zones_lockdown",
        "stays_open", "stays_closed",
    )

    def counters(self):
        """0x07 -- read the maintenance counter block."""
        p = self.call(OP_COUNTERS)
        vals = struct.unpack_from("<17I", p, 0)
        return dict(zip(self.COUNTER_NAMES, vals))

    def site_info(self):
        """0x08 -- read the site record."""
        p = self.call(OP_SITE_INFO)
        name_len, name = p[0], p[1:41]
        addr_len, addr = p[41], p[42:106]
        inst_len, inst = p[106], p[107:139]
        tick_len, tick = p[139], p[140:156]
        return {
            "name": name[:name_len].decode("latin-1"),
            "addr": addr[:addr_len].decode("latin-1"),
            "inst": inst[:inst_len].decode("latin-1"),
            "tick": tick[:tick_len].decode("latin-1"),
            "service_offset": struct.unpack_from("<I", p, 156)[0],
            "site_id": struct.unpack_from("<H", p, 160)[0],
            "reserved": struct.unpack_from("<H", p, 162)[0],
        }

    # ---- stays ----

    def stay_open(self, room_no, party, nights, name=b""):
        """0x10 -- open a stay on a guest room."""
        if isinstance(name, str):
            name = name.encode("latin-1")
        body = struct.pack("<HBBB", room_no, party, nights, len(name)) + name
        p = self.call(OP_STAY_OPEN, body)
        handle, check_in, check_out = struct.unpack_from("<III", p, 0)
        return {"handle": handle, "check_in": check_in,
                "check_out": check_out}

    def stay_close(self, handle):
        """0x11 -- close a stay and void the credentials it owns."""
        p = self.call(OP_STAY_CLOSE, struct.pack("<I", handle))
        return {"handle": struct.unpack_from("<I", p, 0)[0],
                "voided": struct.unpack_from("<H", p, 4)[0]}

    def stay_get(self, handle):
        """0x12 -- read one stay record."""
        p = self.call(OP_STAY_GET, struct.pack("<I", handle))
        name_len = p[18]
        return {
            "handle": struct.unpack_from("<I", p, 0)[0],
            "room_no": struct.unpack_from("<H", p, 4)[0],
            "state": p[6],
            "party": p[7],
            "check_in": struct.unpack_from("<I", p, 8)[0],
            "check_out": struct.unpack_from("<I", p, 12)[0],
            "cred_count": struct.unpack_from("<H", p, 16)[0],
            "name_len": name_len,
            "name": p[19:19 + name_len].decode("latin-1"),
        }

    def stay_list(self, first=0, count=16):
        """0x13 -- page through the stay table."""
        p = self.call(OP_STAY_LIST, struct.pack("<BB", first, count))
        returned, total = p[0], p[1]
        rows = []
        for i in range(returned):
            o = 2 + 8 * i
            rows.append({
                "handle": struct.unpack_from("<I", p, o)[0],
                "room_no": struct.unpack_from("<H", p, o + 4)[0],
                "state": p[o + 6],
                "party": p[o + 7],
            })
        return {"returned": returned, "total": total, "rows": rows}

    def stay_extend(self, handle, nights):
        """0x14 -- push the departure of an open stay out by whole nights."""
        p = self.call(OP_STAY_EXTEND, struct.pack("<IB", handle, nights))
        return {"handle": struct.unpack_from("<I", p, 0)[0],
                "check_out": struct.unpack_from("<I", p, 4)[0]}

    def stay_move(self, handle, room_no):
        """0x15 -- move an open stay to another guest room."""
        p = self.call(OP_STAY_MOVE, struct.pack("<IH", handle, room_no))
        return {"handle": struct.unpack_from("<I", p, 0)[0],
                "room_no": struct.unpack_from("<H", p, 4)[0],
                "voided": struct.unpack_from("<H", p, 6)[0]}

    def occupancy(self):
        """0x16 -- per-zone occupancy roll-up."""
        p = self.call(OP_OCCUPANCY)
        rows = []
        for i in range(p[0]):
            o = 1 + 7 * i
            rows.append({
                "zone": p[o],
                "rooms": struct.unpack_from("<H", p, o + 1)[0],
                "occupied": struct.unpack_from("<H", p, o + 3)[0],
                "guests": struct.unpack_from("<H", p, o + 5)[0],
            })
        return rows

    # ---- credentials ----

    @staticmethod
    def _cred_reply(p):
        return {
            "cred_id": struct.unpack_from("<I", p, 0)[0],
            "blob": p[4:12],
            "expires": struct.unpack_from("<I", p, 12)[0],
            "seq": p[16],
        }

    def cred_issue(self, handle, note=b""):
        """0x20 -- encode a guest credential against an open stay."""
        if isinstance(note, str):
            note = note.encode("latin-1")
        body = struct.pack("<IB", handle, len(note)) + note
        return self._cred_reply(self.call(OP_CRED_ISSUE, body))

    def cred_reissue(self, cred_id, note=b""):
        """0x21 -- replace an active credential with a fresh encoding."""
        if isinstance(note, str):
            note = note.encode("latin-1")
        body = struct.pack("<IB", cred_id, len(note)) + note
        return self._cred_reply(self.call(OP_CRED_REISSUE, body))

    def cred_void(self, cred_id):
        """0x22 -- void one credential."""
        p = self.call(OP_CRED_VOID, struct.pack("<I", cred_id))
        return {"cred_id": struct.unpack_from("<I", p, 0)[0],
                "voided": p[4]}

    def cred_get(self, cred_id):
        """0x23 -- read one credential record."""
        p = self.call(OP_CRED_GET, struct.pack("<I", cred_id))
        card_len = p[32]
        return {
            "cred_id": struct.unpack_from("<I", p, 0)[0],
            "owner": struct.unpack_from("<I", p, 4)[0],
            "klass": p[8],
            "flags": p[9],
            "seq": p[10],
            "room_no": struct.unpack_from("<H", p, 12)[0],
            "zone_mask": struct.unpack_from("<H", p, 14)[0],
            "issued": struct.unpack_from("<I", p, 16)[0],
            "expires": struct.unpack_from("<I", p, 20)[0],
            "blob": p[24:32],
            "card_no_len": card_len,
            "card_no": p[33:33 + card_len].decode("latin-1"),
        }

    def cred_list(self, owner, first=0, count=16):
        """0x24 -- page through the credentials of one owner."""
        body = struct.pack("<IBB", owner, first, count)
        p = self.call(OP_CRED_LIST, body)
        returned = p[0]
        total = struct.unpack_from("<H", p, 1)[0]
        rows = []
        for i in range(returned):
            o = 3 + 10 * i
            rows.append({
                "cred_id": struct.unpack_from("<I", p, o)[0],
                "klass": p[o + 4],
                "flags": p[o + 5],
                "expires": struct.unpack_from("<I", p, o + 6)[0],
            })
        return {"returned": returned, "total": total, "rows": rows}

    def cred_verify(self, cred_id, blob, door_id, at=0):
        """0x25 -- ask the unit how a credential would read at a door."""
        blob = bytes(blob)
        body = struct.pack("<I", cred_id) + blob + \
            struct.pack("<HI", door_id, at)
        p = self.call(OP_CRED_VERIFY, body)
        return {
            "verdict": p[0],
            "reason": p[1],
            "door_id": struct.unpack_from("<H", p, 2)[0],
            "zone": p[4],
            "reserved": p[5],
        }

    def staff_cred_issue(self, staff_id, zone_mask, days, note=b""):
        """0x26 -- encode a staff credential."""
        if isinstance(note, str):
            note = note.encode("latin-1")
        body = struct.pack("<HHBB", staff_id, zone_mask, days,
                           len(note)) + note
        return self._cred_reply(self.call(OP_STAFF_CRED_ISSUE, body))

    # ---- lock map, zones, schedule, door export ----

    def door_list(self, first=0, count=16):
        """0x30 -- page through the lock map."""
        p = self.call(OP_DOOR_LIST, struct.pack("<HB", first, count))
        returned = p[0]
        total = struct.unpack_from("<H", p, 1)[0]
        rows = []
        for i in range(returned):
            o = 3 + 8 * i
            rows.append({
                "door_id": struct.unpack_from("<H", p, o)[0],
                "room_no": struct.unpack_from("<H", p, o + 2)[0],
                "zone": p[o + 4],
                "flags": p[o + 5],
                "model": p[o + 6],
                "battery": p[o + 7],
            })
        return {"returned": returned, "total": total, "rows": rows}

    def door_get(self, door_id):
        """0x31 -- read one door record."""
        p = self.call(OP_DOOR_GET, struct.pack("<H", door_id))
        label_len = p[13]
        bus_len = p[24]
        return {
            "door_id": struct.unpack_from("<H", p, 0)[0],
            "room_no": struct.unpack_from("<H", p, 2)[0],
            "zone": p[4],
            "flags": p[5],
            "model": p[6],
            "fw": p[7],
            "last_seen": struct.unpack_from("<I", p, 8)[0],
            "battery": p[12],
            "label_len": label_len,
            "label": p[14:14 + label_len].decode("latin-1"),
            "bus_len": bus_len,
            "bus": p[25:25 + bus_len],
        }

    def door_set_flags(self, door_id, set_bits, clear_bits):
        """0x32 -- set and clear service flags on one door."""
        body = struct.pack("<HBB", door_id, set_bits, clear_bits)
        p = self.call(OP_DOOR_SET_FLAGS, body)
        return {"door_id": struct.unpack_from("<H", p, 0)[0], "flags": p[2]}

    def zone_list(self):
        """0x33 -- list the zones that are in service."""
        p = self.call(OP_ZONE_LIST)
        rows = []
        for i in range(p[0]):
            o = 1 + 8 * i
            rows.append({
                "zone": p[o],
                "flags": p[o + 1],
                "door_count": struct.unpack_from("<H", p, o + 2)[0],
                "curfew_start": struct.unpack_from("<H", p, o + 4)[0],
                "curfew_end": struct.unpack_from("<H", p, o + 6)[0],
            })
        return rows

    def zone_get(self, zone_id):
        """0x34 -- read one zone record."""
        p = self.call(OP_ZONE_GET, struct.pack("<B", zone_id))
        name_len = p[8]
        return {
            "zone": p[0],
            "flags": p[1],
            "door_count": struct.unpack_from("<H", p, 2)[0],
            "curfew_start": struct.unpack_from("<H", p, 4)[0],
            "curfew_end": struct.unpack_from("<H", p, 6)[0],
            "name_len": name_len,
            "name": p[9:9 + name_len].decode("latin-1"),
        }

    def zone_lockdown(self, zone_id, on):
        """0x35 -- place a zone into or out of lockdown."""
        p = self.call(OP_ZONE_LOCKDOWN, struct.pack("<BB", zone_id, on))
        return {"zone": p[0], "flags": p[1],
                "doors": struct.unpack_from("<H", p, 2)[0]}

    @staticmethod
    def _swin(p, o=0):
        return {
            "window_id": p[o],
            "zone": p[o + 1],
            "mode": p[o + 2],
            "days": p[o + 3],
            "start_min": struct.unpack_from("<H", p, o + 4)[0],
            "end_min": struct.unpack_from("<H", p, o + 6)[0],
            "hits": struct.unpack_from("<I", p, o + 8)[0],
        }

    def sched_list(self):
        """0x36 -- list the schedule windows in use."""
        p = self.call(OP_SCHED_LIST)
        return [self._swin(p, 1 + 12 * i) for i in range(p[0])]

    def sched_set(self, window_id, zone, mode, days, start_min, end_min):
        """0x37 -- create (window_id 0) or overwrite a schedule window."""
        body = struct.pack("<BBBBHH", window_id, zone, mode, days,
                           start_min, end_min)
        return self._swin(self.call(OP_SCHED_SET, body))

    def door_export(self, door_ids):
        """0x38 -- render a door batch into the PMS import region."""
        body = struct.pack("<B", len(door_ids))
        for d in door_ids:
            body += struct.pack("<H", d)
        p = self.call(OP_DOOR_EXPORT, body)
        return {"rendered": struct.unpack_from("<H", p, 0)[0],
                "skipped": struct.unpack_from("<H", p, 2)[0]}

    # ---- staff ----

    def staff_list(self, first=0, count=16):
        """0x40 -- page through the staff table."""
        p = self.call(OP_STAFF_LIST, struct.pack("<BB", first, count))
        returned, total = p[0], p[1]
        rows = []
        for i in range(returned):
            o = 2 + 6 * i
            rows.append({
                "staff_id": struct.unpack_from("<H", p, o)[0],
                "klass": p[o + 2],
                "flags": p[o + 3],
                "zone_mask": struct.unpack_from("<H", p, o + 4)[0],
            })
        return {"returned": returned, "total": total, "rows": rows}

    def staff_get(self, staff_id):
        """0x41 -- read one staff record."""
        p = self.call(OP_STAFF_GET, struct.pack("<H", staff_id))
        name_len = p[16]
        return {
            "staff_id": struct.unpack_from("<H", p, 0)[0],
            "klass": p[2],
            "flags": p[3],
            "days": p[4],
            "start_min": struct.unpack_from("<H", p, 6)[0],
            "end_min": struct.unpack_from("<H", p, 8)[0],
            "zone_mask": struct.unpack_from("<H", p, 10)[0],
            "cred_count": struct.unpack_from("<I", p, 12)[0],
            "name_len": name_len,
            "name": p[17:17 + name_len].decode("latin-1"),
        }

    def staff_set_window(self, staff_id, days, start_min, end_min):
        """0x42 -- set the duty window of one staff record."""
        body = struct.pack("<HBHH", staff_id, days, start_min, end_min)
        p = self.call(OP_STAFF_SET_WINDOW, body)
        return {
            "staff_id": struct.unpack_from("<H", p, 0)[0],
            "days": p[2],
            "start_min": struct.unpack_from("<H", p, 3)[0],
            "end_min": struct.unpack_from("<H", p, 5)[0],
        }

    # ---- journal and export ----

    def jrnl_count(self):
        """0x50 -- journal depth and the oldest/newest entry ids."""
        p = self.call(OP_JRNL_COUNT)
        count, oldest, newest = struct.unpack_from("<HHH", p, 0)
        return {"count": count, "oldest_id": oldest, "newest_id": newest}

    def jrnl_get(self, entry_id):
        """0x51 -- read one journal entry."""
        p = self.call(OP_JRNL_GET, struct.pack("<I", entry_id))
        text_len = p[16]
        return {
            "entry_id": struct.unpack_from("<I", p, 0)[0],
            "ts": struct.unpack_from("<I", p, 4)[0],
            "kind": p[8],
            "actor": p[9],
            "room_no": struct.unpack_from("<H", p, 10)[0],
            "subject": struct.unpack_from("<I", p, 12)[0],
            "text_len": text_len,
            "text": p[17:17 + text_len],
        }

    def jrnl_find(self, kind=0, room_no=0, ts_from=0, ts_to=0, limit=32):
        """0x52 -- select journal entry ids by kind, room and time span."""
        body = struct.pack("<BHIIB", kind, room_no, ts_from, ts_to, limit)
        p = self.call(OP_JRNL_FIND, body)
        returned = p[0]
        return [struct.unpack_from("<I", p, 1 + 4 * i)[0]
                for i in range(returned)]

    def jrnl_peek(self, entry_id):
        """0x53 -- render one journal entry in the peek form."""
        p = self.call(OP_JRNL_PEEK, struct.pack("<I", entry_id))
        n = struct.unpack_from("<H", p, 0)[0]
        return p[2:2 + n].decode("latin-1")

    def export_begin(self, entry_ids):
        """0x54 -- render a journal batch into the PMS import region."""
        body = struct.pack("<B", len(entry_ids))
        for e in entry_ids:
            body += struct.pack("<I", e)
        p = self.call(OP_EXPORT_BEGIN, body)
        return {"rendered": struct.unpack_from("<H", p, 0)[0],
                "skipped": struct.unpack_from("<H", p, 2)[0]}

    def export_fetch(self, want=256):
        """0x55 -- fetch the next slice of import text from the batch."""
        p = self.call(OP_EXPORT_FETCH, struct.pack("<H", want))
        n = struct.unpack_from("<H", p, 0)[0]
        return p[2:2 + n]

    def export_drain(self, chunk=256):
        """Repeat 0x55 until the batch is exhausted; return the whole text."""
        out = b""
        while True:
            part = self.export_fetch(chunk)
            if not part:
                return out
            out += part

    def export_stat(self):
        """0x56 -- batch counters for the current batch."""
        p = self.call(OP_EXPORT_STAT)
        rendered, skipped, remaining = struct.unpack_from("<HHH", p, 0)
        return {"rendered": rendered, "skipped": skipped,
                "remaining": remaining,
                "batch_seq": struct.unpack_from("<I", p, 6)[0]}


def _demo(host, port):
    with KX(host, port) as kx:
        dev = kx.devinfo()
        print("device")
        print("  serial      %s" % dev["serial"])
        print("  mac         %s" % dev["mac"])
        print("  firmware    %d.%d.%d (hw rev %d, build %08X)" % (
            dev["fw_major"], dev["fw_minor"], dev["fw_patch"],
            dev["hw_rev"], dev["build"]))

        site = kx.site_info()
        print("  site        %s (id %d)" % (site["name"], site["site_id"]))

        print("doors")
        doors = kx.door_list(first=0, count=5)
        print("  %d of %d provisioned" % (doors["returned"], doors["total"]))
        for d in doors["rows"]:
            full = kx.door_get(d["door_id"])
            print("  %5d  room %-5d zone %-3d flags %02X  %s" % (
                full["door_id"], full["room_no"], full["zone"],
                full["flags"], full["label"]))

        # Pick a free guest room from the lock map for the demo stay.
        room = None
        busy = {r["room_no"] for r in kx.stay_list(0, 64)["rows"]
                if r["state"] == 1}
        page = kx.door_list(first=0, count=64)
        for d in page["rows"]:
            if d["room_no"] and d["room_no"] not in busy:
                room = d["room_no"]
                break
        if room is None:
            print("no free guest room in the first page of the lock map")
            return

        print("stay")
        stay = kx.stay_open(room, party=2, nights=3, name="DEMO PARTY")
        print("  handle %d on room %d" % (stay["handle"], room))
        print("  %s" % kx.stay_get(stay["handle"]))

        print("credential")
        cred = kx.cred_issue(stay["handle"], note="front desk demo")
        rec = kx.cred_get(cred["cred_id"])
        print("  id %d  card %s  klass %d  zones %04X" % (
            rec["cred_id"], rec["card_no"], rec["klass"], rec["zone_mask"]))
        door_id = kx.door_list(0, 64)["rows"][0]["door_id"]
        verify = kx.cred_verify(rec["cred_id"], rec["blob"], door_id)
        print("  verify at door %d -> verdict %d reason %d" % (
            door_id, verify["verdict"], verify["reason"]))

        print("staff")
        staff = kx.staff_list(0, 3)
        for s in staff["rows"]:
            full = kx.staff_get(s["staff_id"])
            print("  %4d  klass %d  %02d:%02d-%02d:%02d  %s" % (
                full["staff_id"], full["klass"],
                full["start_min"] // 60, full["start_min"] % 60,
                full["end_min"] // 60, full["end_min"] % 60,
                full["name"]))

        print("journal batch")
        ids = kx.jrnl_find(kind=0, limit=6)
        begin = kx.export_begin(ids)
        print("  rendered %d  skipped %d" % (begin["rendered"],
                                             begin["skipped"]))
        text = kx.export_drain()
        for line in text.split(b"\n"):
            print("  | %s" % line.decode("latin-1"))
        print("  %s" % kx.export_stat())


if __name__ == "__main__":
    _host = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
    _port = int(sys.argv[2]) if len(sys.argv) > 2 else 1337
    _demo(_host, _port)
