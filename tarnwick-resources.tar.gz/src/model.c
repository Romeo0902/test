#include "kexd.h"

/* ---- model ---- */

uint32_t dev_uptime(void)
{
    time_t now = time(NULL);
    if (now < BOOT_TS)
        return 0;
    return (uint32_t)(now - BOOT_TS);
}

uint32_t dev_seconds(void)
{
    return (uint32_t)SVC_BASE + dev_uptime();
}

uint32_t cnt_cards_encoded(void)
{
    return C_ENC0 + dev_seconds() / 2404u + SESS_ISSUED;
}

uint32_t cnt_cards_voided(void)
{
    return C_VOID0 + dev_seconds() / 9007u + SESS_VOIDED;
}

uint32_t cnt_head_cycles(void)
{
    return 2u * cnt_cards_encoded() + dev_seconds() / 4001u;
}

uint32_t cnt_head_faults(void)
{
    return dev_seconds() / 86400u;
}

uint32_t cnt_mains_events(void)
{
    return dev_seconds() / 604800u;
}

uint32_t cnt_reader_resets(void)
{
    return dev_seconds() / 172800u;
}

uint32_t cnt_reader_temp(void)
{
    return 372u + (dev_seconds() / 60u) % 23u;
}

uint32_t cnt_sync_age(void)
{
    return dev_seconds() % 3607u;
}

uint32_t swin_hits(const struct swin *w)
{
    return w->hits + dev_seconds() / 86400u;
}

uint32_t doors_provisioned(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < DOOR_MAX; i++)
        if (DOORS[i].id != 0)
            n++;
    return n;
}

uint32_t doors_online(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < DOOR_MAX; i++)
        if (DOORS[i].id != 0 && (DOORS[i].flags & 0x08) == 0)
            n++;
    return n;
}

uint32_t doors_offline(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < DOOR_MAX; i++)
        if (DOORS[i].id != 0 && (DOORS[i].flags & 0x08) != 0)
            n++;
    return n;
}

uint32_t doors_lowbatt(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < DOOR_MAX; i++)
        if (DOORS[i].id != 0 && (DOORS[i].flags & 0x10) != 0)
            n++;
    return n;
}

uint32_t zones_in_service(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < ZONE_MAX; i++)
        if (ZONES[i].flags & 0x01)
            n++;
    return n;
}

uint32_t zones_lockdown(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < ZONE_MAX; i++)
        if ((ZONES[i].flags & 0x01) && (ZONES[i].flags & 0x02))
            n++;
    return n;
}

uint32_t stays_open(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < STAY_MAX; i++)
        if (STAYS[i].state == 1)
            n++;
    return n;
}

uint8_t zone_of_room(uint16_t room)
{
    uint32_t i;

    if (room == 0)
        return 0;
    for (i = 0; i < DOOR_MAX; i++)
        if (DOORS[i].id != 0 && DOORS[i].room_no == room)
            return DOORS[i].zone;
    return 0;
}

uint16_t guest_zone_mask(uint16_t room)
{
    uint8_t z = zone_of_room(room);
    uint16_t m = 0x0081;

    if (z >= 1 && z <= 16)
        m |= (uint16_t)(1u << (z - 1));
    return m;
}

uint32_t stays_closed(void)
{
    uint32_t i, n = 0;
    for (i = 0; i < STAY_MAX; i++)
        if (STAYS[i].state == 2)
            n++;
    return n;
}
