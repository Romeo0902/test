#include "kexd.h"

/* ---- config ---- */

/*
 * Each table is loaded from a plain line-oriented file under /etc/kexd: one
 * record per line, comma separated, lines beginning with # ignored, and a
 * built-in record used when the file is absent.
 */

#define CF_DEVICE 0
#define CF_DOORS  1
#define CF_ZONES  2
#define CF_STAFF  3
#define CF_SCHED  4
#define CF_KEY    5

static const char *const CF_PATH[6] = {
    "/etc/kexd/device.id",
    "/etc/kexd/doors.map",
    "/etc/kexd/zones.map",
    "/etc/kexd/staff.tab",
    "/etc/kexd/sched.tab",
    "/etc/kexd/site.key"
};

static const char *const CF_DFLT[6] = {
    "TK220-000000000000,02:1B:9A:40:11:07,4,3.12.7,00517A04",
    "1,0,1,01,LOBBY MAIN,00",
    "1,01,0000,1439,DEFAULT",
    "1,3,7F,0480,1080,FRONT DESK",
    "1,1,3,7F,0000,1439",
    "TK220-4E51-0000-0000-0000"
};

static void copy_text(uint8_t *dst, size_t cap, const char *src)
{
    size_t i;

    memset(dst, 0, cap);
    for (i = 0; i < cap; i++) {
        unsigned char c = (unsigned char)src[i];
        if (c < 0x20 || c > 0x7e)
            break;
        dst[i] = c;
    }
}

static size_t unhex(const char *src, uint8_t *dst, size_t cap)
{
    size_t n = 0;

    while (n < cap) {
        int hi = -1, lo = -1;
        char a = src[2 * n], b = src[2 * n + 1];
        if (a >= '0' && a <= '9') hi = a - '0';
        else if (a >= 'A' && a <= 'F') hi = a - 'A' + 10;
        else if (a >= 'a' && a <= 'f') hi = a - 'a' + 10;
        if (b >= '0' && b <= '9') lo = b - '0';
        else if (b >= 'A' && b <= 'F') lo = b - 'A' + 10;
        else if (b >= 'a' && b <= 'f') lo = b - 'a' + 10;
        if (hi < 0 || lo < 0)
            break;
        dst[n++] = (uint8_t)((hi << 4) | lo);
    }
    return n;
}

static struct siterec SITE;

const struct siterec *site_rec(void)
{
    return &SITE;
}

static void apply_site(const char *line)
{
    char nm[48], ad[80], ins[40], tk[24];
    unsigned sid = 0;

    nm[0] = ad[0] = ins[0] = tk[0] = '\0';
    if (sscanf(line + 2, "%u,%39[^,],%63[^,],%31[^,],%15[^,\n]",
               &sid, nm, ad, ins, tk) < 5)
        return;
    SITE.site_id = (uint16_t)sid;
    copy_text(SITE.name, sizeof SITE.name, nm);
    copy_text(SITE.addr, sizeof SITE.addr, ad);
    copy_text(SITE.inst, sizeof SITE.inst, ins);
    copy_text(SITE.tick, sizeof SITE.tick, tk);
}

static void apply_device(const char *line)
{
    if (line[0] == 'S' && line[1] == ',') {
        apply_site(line);
        return;
    }

    char ser[20], mac[20];
    unsigned hw = 4, a = 3, b = 12, c = 7, bid = BUILD_ID;
    unsigned m0, m1, m2, m3, m4, m5;

    ser[0] = '\0';
    mac[0] = '\0';
    if (sscanf(line, "%17[^,],%17[^,],%u,%u.%u.%u,%8x",
               ser, mac, &hw, &a, &b, &c, &bid) < 6)
        return;
    copy_text(DEV.serial, sizeof DEV.serial, ser);
    if (sscanf(mac, "%2x:%2x:%2x:%2x:%2x:%2x", &m0, &m1, &m2, &m3, &m4, &m5) == 6) {
        DEV.mac[0] = (uint8_t)m0;
        DEV.mac[1] = (uint8_t)m1;
        DEV.mac[2] = (uint8_t)m2;
        DEV.mac[3] = (uint8_t)m3;
        DEV.mac[4] = (uint8_t)m4;
        DEV.mac[5] = (uint8_t)m5;
    }
    DEV.hw_rev = (uint8_t)(hw & 0xff);
    DEV.fw_major = (uint8_t)(a & 0xff);
    DEV.fw_minor = (uint8_t)(b & 0xff);
    DEV.fw_patch = (uint8_t)(c & 0xff);
    DEV.build = bid;
}

static void apply_door(const char *line)
{
    char label[16], bus[24];
    unsigned id = 0, room = 0, zone = 0, flags = 0;
    struct door *d;
    size_t n;

    label[0] = '\0';
    bus[0] = '\0';
    if (sscanf(line, "%u,%u,%u,%2x,%10[^,],%16[^,\n]",
               &id, &room, &zone, &flags, label, bus) < 5)
        return;
    if (id == 0 || id > DOOR_MAX || zone == 0 || zone > ZONE_MAX)
        return;
    d = &DOORS[id - 1];
    d->id = (uint16_t)id;
    d->room_no = (uint16_t)room;
    d->zone = (uint8_t)zone;
    d->flags = (uint8_t)(flags | 0x01);
    copy_text(d->label, sizeof d->label, label);
    n = unhex(bus, d->bus, sizeof d->bus);
    d->bus_len = (uint8_t)n;
}

static void apply_zone(const char *line)
{
    char name[32];
    unsigned id = 0, flags = 0, cs = 0, ce = 1439;
    struct zone *z;

    name[0] = '\0';
    if (sscanf(line, "%u,%2x,%u,%u,%24[^,\n]", &id, &flags, &cs, &ce, name) < 5)
        return;
    if (id == 0 || id > ZONE_MAX || cs > 1439 || ce > 1439)
        return;
    z = &ZONES[id - 1];
    z->id = (uint8_t)id;
    z->flags = (uint8_t)(flags | 0x01);
    z->curfew_start = (uint16_t)cs;
    z->curfew_end = (uint16_t)ce;
    copy_text(z->name, sizeof z->name, name);
}

static void apply_staff(const char *line)
{
    char name[64];
    unsigned id = 0, klass = 0, days = 0, s = 0, e = 0, zm = 0;
    struct staff *p;
    uint32_t i;

    name[0] = '\0';
    if (sscanf(line, "%u,%u,%2x,%u,%u,%4x,%47[^,\n]",
               &id, &klass, &days, &s, &e, &zm, name) < 7) {
        zm = CAPS_BITS;
        name[0] = '\0';
        if (sscanf(line, "%u,%u,%2x,%u,%u,%47[^,\n]",
                   &id, &klass, &days, &s, &e, name) < 6)
            return;
    }
    if (id == 0 || klass == 0 || klass > 5 || s > 1439 || e > 1439)
        return;
    for (i = 0; i < STAFF_MAX; i++)
        if (STAFF[i].id == 0)
            break;
    if (i == STAFF_MAX)
        return;
    p = &STAFF[i];
    p->id = (uint16_t)id;
    p->klass = (uint8_t)klass;
    p->flags = 0x01;
    p->days = (uint8_t)(days & 0x7f);
    p->start_min = (uint16_t)s;
    p->end_min = (uint16_t)e;
    p->zone_mask = (uint16_t)zm;
    copy_text(p->name, sizeof p->name, name);
}

static void apply_sched(const char *line)
{
    unsigned id = 0, zone = 0, mode = 0, days = 0, s = 0, e = 0;
    struct swin *w;

    if (sscanf(line, "%u,%u,%u,%2x,%u,%u", &id, &zone, &mode, &days, &s, &e) < 6)
        return;
    if (id == 0 || id > SCHED_MAX || zone == 0 || zone > ZONE_MAX)
        return;
    if (mode == 0 || mode > 3 || s > 1439 || e > 1439 || s == e)
        return;
    w = &SCHED[id - 1];
    w->id = (uint8_t)id;
    w->zone = (uint8_t)zone;
    w->mode = (uint8_t)mode;
    w->days = (uint8_t)(days & 0x7f);
    w->start_min = (uint16_t)s;
    w->end_min = (uint16_t)e;
    w->in_use = 1;
}

static void apply_key(const char *line)
{
    size_t n = strlen(line);

    if (n == 0)
        return;
    if (n > sizeof SITE_KEY - 1)
        n = sizeof SITE_KEY - 1;
    memset(SITE_KEY, 0, sizeof SITE_KEY);
    memcpy(SITE_KEY, line, n);
}

static uint8_t POOL_NAME[48][24];
static uint8_t POOL_NOTE[32][40];
static uint8_t POOL_NAME_N;
static uint8_t POOL_NOTE_N;

const uint8_t *pool_name(unsigned i)
{
    return POOL_NAME[POOL_NAME_N ? i % POOL_NAME_N : 0];
}

const uint8_t *pool_note(unsigned i)
{
    return POOL_NOTE[POOL_NOTE_N ? i % POOL_NOTE_N : 0];
}

const uint8_t *pool_note_at(unsigned i)
{
    return POOL_NOTE[i < POOL_NOTE_N ? i : 0];
}

uint8_t note_index(uint8_t kind, uint8_t reason, uint32_t pick)
{
    switch (kind) {
    case 8:  return (uint8_t)((reason >= 1 && reason <= 8) ? reason - 1 : 0);
    case 5:  return (uint8_t)(8 + pick % 3u);
    case 6:  return (uint8_t)(11 + pick % 3u);
    case 7:  return (uint8_t)(14 + pick % 2u);
    case 9:  return (uint8_t)(16 + pick % 3u);
    case 10: return (uint8_t)(19 + pick % 3u);
    case 11: return 22;
    case 12: return 23;
    case 13: return 24;
    default: return 25;
    }
}

unsigned pool_name_count(void)
{
    return POOL_NAME_N;
}

unsigned pool_note_count(void)
{
    return POOL_NOTE_N;
}

static void apply_pool(const char *line)
{
    if (line[0] == 'P' && POOL_NAME_N < 48)
        copy_text(POOL_NAME[POOL_NAME_N++], sizeof POOL_NAME[0], line + 2);
    else if (line[0] == 'Q' && POOL_NOTE_N < 32)
        copy_text(POOL_NOTE[POOL_NOTE_N++], sizeof POOL_NOTE[0], line + 2);
}

static void conf_apply(int kind, const char *line)
{
    if (kind == CF_STAFF && (line[0] == 'P' || line[0] == 'Q') && line[1] == ',') {
        apply_pool(line);
        return;
    }
    switch (kind) {
    case CF_DEVICE: apply_device(line); break;
    case CF_DOORS:  apply_door(line);   break;
    case CF_ZONES:  apply_zone(line);   break;
    case CF_STAFF:  apply_staff(line);  break;
    case CF_SCHED:  apply_sched(line);  break;
    default:        apply_key(line);    break;
    }
}

static void conf_load(int kind)
{
    char line[256];
    FILE *f;
    int used = 0;

    f = fopen(CF_PATH[kind], "r");
    if (f) {
        while (fgets(line, sizeof line, f)) {
            size_t n = strlen(line);
            while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r'))
                line[--n] = '\0';
            if (n == 0 || line[0] == '#')
                continue;
            conf_apply(kind, line);
            used = 1;
        }
        fclose(f);
    }
    if (!used)
        conf_apply(kind, CF_DFLT[kind]);
}

void conf_load_all(void)
{
    int i;

    for (i = 0; i < 6; i++)
        conf_load(i);
    SUBKEY = fold64((const uint8_t *)SITE_KEY, strlen(SITE_KEY),
                    0xcbf29ce484222325ULL);
}
