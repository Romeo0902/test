#include "kexd.h"

/* ---- staff ---- */

int h_staff_list(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[3 + LIST_CAP * 6];
    uint8_t first, count, ret = 0;
    uint32_t i, total = 0, seen = 0;

    if (len != 2)
        return send_status(fd, OP_STAFF_LIST, ST_BODY);
    first = b[0];
    count = b[1];
    if (count > LIST_CAP)
        return send_status(fd, OP_STAFF_LIST, ST_BODY);

    for (i = 0; i < STAFF_MAX; i++)
        if (STAFF[i].id != 0)
            total++;
    for (i = 0; i < STAFF_MAX && ret < count; i++) {
        struct staff *p = &STAFF[i];
        uint8_t *q;
        if (p->id == 0)
            continue;
        if (seen++ < first)
            continue;
        q = out + 3 + 6 * ret;
        put_u16(q, p->id);
        q[2] = p->klass;
        q[3] = p->flags;
        put_u16(q + 4, p->zone_mask);
        ret++;
    }
    out[0] = ST_OK;
    out[1] = ret;
    out[2] = (uint8_t)total;
    return send_frame(fd, OP_STAFF_LIST, out, 3 + (size_t)ret * 6);
}

int h_staff_get(int fd, const uint8_t *b, uint16_t len)
{
    struct staff *p;
    uint8_t out[66];

    if (len != 2)
        return send_status(fd, OP_STAFF_GET, ST_BODY);
    p = staff_find(get_u16(b));
    if (!p)
        return send_status(fd, OP_STAFF_GET, ST_NOENT);

    memset(out, 0, sizeof out);
    out[0] = ST_OK;
    put_u16(out + 1, p->id);
    out[3] = p->klass;
    out[4] = p->flags;
    out[5] = p->days;
    out[6] = 0;
    put_u16(out + 7, p->start_min);
    put_u16(out + 9, p->end_min);
    put_u16(out + 11, p->zone_mask);
    put_u32(out + 13, p->cred_count);
    out[17] = (uint8_t)strnlen((const char *)p->name, STAFF_NAME_LEN);
    memcpy(out + 18, p->name, STAFF_NAME_LEN);
    return send_frame(fd, OP_STAFF_GET, out, 66);
}

int h_staff_set_window(int fd, const uint8_t *b, uint16_t len)
{
    struct staff *p;
    uint8_t days, out[8];
    uint16_t s, e;

    if (len != 7)
        return send_status(fd, OP_STAFF_SET_WINDOW, ST_BODY);
    days = b[2];
    s = get_u16(b + 3);
    e = get_u16(b + 5);
    if ((days & 0x80) || s > 1439 || e > 1439 || s == e)
        return send_status(fd, OP_STAFF_SET_WINDOW, ST_BODY);
    p = staff_find(get_u16(b));
    if (!p)
        return send_status(fd, OP_STAFF_SET_WINDOW, ST_NOENT);

    p->days = days;
    p->start_min = s;
    p->end_min = e;

    out[0] = ST_OK;
    put_u16(out + 1, p->id);
    out[3] = p->days;
    put_u16(out + 4, p->start_min);
    put_u16(out + 6, p->end_min);
    return send_frame(fd, OP_STAFF_SET_WINDOW, out, sizeof out);
}
