/*
 * kexd - key encoder daemon for the Tarnwick TK-220 front-desk appliance.
 *
 * The KX01 control port is the interface a property-management system uses to
 * drive the unit: stays, credentials, the lock map, zone schedules and the
 * event journal.
 */
#include "kexd.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/types.h>

/* ---- session ---- */

static int dispatch(int fd, uint8_t op, const uint8_t *body, uint16_t len)
{
    switch (op) {
    case OP_HELLO:            return h_hello(fd, body, len);
    case OP_DEVINFO:          return h_devinfo(fd, body, len);
    case OP_CLOCK_GET:        return h_clock_get(fd, body, len);
    case OP_CLOCK_SET:        return h_clock_set(fd, body, len);
    case OP_DIAG_SELFTEST:    return h_diag_selftest(fd, body, len);
    case OP_DIAG_TEXT:        return h_diag_text(fd, body, len);
    case OP_COUNTERS:         return h_counters(fd, body, len);
    case OP_SITE_INFO:        return h_site_info(fd, body, len);
    case OP_STAY_OPEN:        return h_stay_open(fd, body, len);
    case OP_STAY_CLOSE:       return h_stay_close(fd, body, len);
    case OP_STAY_GET:         return h_stay_get(fd, body, len);
    case OP_STAY_LIST:        return h_stay_list(fd, body, len);
    case OP_STAY_EXTEND:      return h_stay_extend(fd, body, len);
    case OP_STAY_MOVE:        return h_stay_move(fd, body, len);
    case OP_OCCUPANCY:        return h_occupancy(fd, body, len);
    case OP_CRED_ISSUE:       return h_cred_issue(fd, body, len);
    case OP_CRED_REISSUE:     return h_cred_reissue(fd, body, len);
    case OP_CRED_VOID:        return h_cred_void(fd, body, len);
    case OP_CRED_GET:         return h_cred_get(fd, body, len);
    case OP_CRED_LIST:        return h_cred_list(fd, body, len);
    case OP_CRED_VERIFY:      return h_cred_verify(fd, body, len);
    case OP_STAFF_CRED_ISSUE: return h_staff_cred_issue(fd, body, len);
    case OP_DOOR_LIST:        return h_door_list(fd, body, len);
    case OP_DOOR_GET:         return h_door_get(fd, body, len);
    case OP_DOOR_SET_FLAGS:   return h_door_set_flags(fd, body, len);
    case OP_ZONE_LIST:        return h_zone_list(fd, body, len);
    case OP_ZONE_GET:         return h_zone_get(fd, body, len);
    case OP_ZONE_LOCKDOWN:    return h_zone_lockdown(fd, body, len);
    case OP_SCHED_LIST:       return h_sched_list(fd, body, len);
    case OP_SCHED_SET:        return h_sched_set(fd, body, len);
    case OP_DOOR_EXPORT:      return h_door_export(fd, body, len);
    case OP_STAFF_LIST:       return h_staff_list(fd, body, len);
    case OP_STAFF_GET:        return h_staff_get(fd, body, len);
    case OP_STAFF_SET_WINDOW: return h_staff_set_window(fd, body, len);
    case OP_JRNL_COUNT:       return h_jrnl_count(fd, body, len);
    case OP_JRNL_GET:         return h_jrnl_get(fd, body, len);
    case OP_JRNL_FIND:        return h_jrnl_find(fd, body, len);
    case OP_JRNL_PEEK:        return h_jrnl_peek(fd, body, len);
    case OP_EXPORT_BEGIN:     return h_export_begin(fd, body, len);
    case OP_EXPORT_FETCH:     return h_export_fetch(fd, body, len);
    case OP_EXPORT_STAT:      return h_export_stat(fd, body, len);
    default:
        send_status(fd, op, ST_OPCODE);
        return -1;
    }
}

static void session(int fd)
{
    uint8_t hdr[8];
    uint8_t body[KX_BODY_MAX];

    for (;;) {
        uint8_t op;
        uint16_t len;

        if (read_full(fd, hdr, sizeof hdr) < 0)
            return;
        op = hdr[4];
        len = (uint16_t)(hdr[6] | ((uint16_t)hdr[7] << 8));
        if (len > KX_BODY_MAX) {
            send_status(fd, op, ST_FRAME);
            return;
        }
        if (len && read_full(fd, body, len) < 0)
            return;
        if (hdr[0] != KX_MAGIC0 || hdr[1] != KX_MAGIC1 ||
            hdr[2] != KX_MAGIC2 || hdr[3] != KX_MAGIC3) {
            send_status(fd, op, ST_FRAME);
            return;
        }
        if (dispatch(fd, op, body, len) < 0)
            return;
    }
}

int main(void)
{
    int srv, opt = 1;
    struct sockaddr_in sa;

    setvbuf(stdout, NULL, _IONBF, 0);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);

    BOOT_TS = time(NULL);
    conf_load_all();
    seed_state();

    srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv < 0)
        return 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof opt);

    memset(&sa, 0, sizeof sa);
    sa.sin_family = AF_INET;
    sa.sin_addr.s_addr = htonl(INADDR_ANY);
    sa.sin_port = htons(KX_PORT);
    if (bind(srv, (struct sockaddr *)&sa, sizeof sa) < 0)
        return 1;
    if (listen(srv, 16) < 0)
        return 1;

    for (;;) {
        int cfd = accept(srv, NULL, NULL);
        pid_t pid;

        if (cfd < 0) {
            if (errno == EINTR)
                continue;
            return 1;
        }
        pid = fork();
        if (pid == 0) {
            close(srv);
            alarm(60);
            session(cfd);
            close(cfd);
            _exit(0);
        }
        close(cfd);
    }
}
