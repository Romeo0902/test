#include "kexd.h"

/* ---- records ---- */

struct devrec DEV;
uint64_t  SUBKEY;
time_t    BOOT_TS;
uint32_t  JRNL_SEQ;
uint32_t  JRNL_FILL;
uint32_t  JRNL_HEAD;
uint32_t  CRED_SEQ;
uint32_t  C_ENC0;
uint32_t  C_VOID0;
uint32_t  SESS_ISSUED;
uint32_t  SESS_VOIDED;
int16_t   TZ_MIN = TZ_MIN_DFLT;
uint8_t   DST_ON = DST_DFLT;

struct jrec  JRNL[JRNL_MAX];
struct cred  CREDS[CRED_MAX];
struct stay  STAYS[STAY_MAX];
struct staff STAFF[STAFF_MAX];
struct swin  SCHED[SCHED_MAX];
char         SITE_KEY[128] __attribute__((aligned(32)));
struct zone  ZONES[ZONE_MAX];
struct door  DOORS[DOOR_MAX];
struct exp_state EXP;

_Static_assert(sizeof(struct door) == 32, "door");
_Static_assert(sizeof(struct zone) == 32, "zone");
_Static_assert(sizeof(struct swin) == 16, "swin");
_Static_assert(sizeof(struct staff) == 64, "staff");
_Static_assert(sizeof(struct stay) == 96, "stay");
_Static_assert(sizeof(struct cred) == 48, "cred");
_Static_assert(sizeof(struct jrec) == 128, "jrec");
_Static_assert(sizeof(EXP.buf) == 3072, "region");
_Static_assert(sizeof(struct exp_state) == 3360, "region");
_Static_assert(sizeof(DOORS) == 32 * DOOR_MAX, "doors");
_Static_assert(sizeof(ZONES) == 1024, "zones");
_Static_assert(sizeof(SCHED) == 1024, "sched");
_Static_assert(sizeof(STAFF) == 4096, "staff");
_Static_assert(sizeof(STAYS) == 6144, "stays");
_Static_assert(sizeof(CREDS) == 12288, "creds");
_Static_assert(sizeof(JRNL) == 49152, "jrnl");
_Static_assert(sizeof(SITE_KEY) == 128, "key");

struct jrec *jrnl_find(uint32_t id)
{
    uint32_t i;
    for (i = 0; i < JRNL_FILL; i++) {
        if (JRNL[i].kind != 0 && JRNL[i].id == id)
            return &JRNL[i];
    }
    return NULL;
}

void jrnl_add(uint8_t kind, uint8_t actor, uint16_t room_no, uint32_t subject,
              const uint8_t *text, uint8_t text_len)
{
    struct jrec *r = &JRNL[JRNL_HEAD];

    memset(r, 0, sizeof *r);
    r->id = JRNL_SEQ;
    r->ts = dev_seconds();
    r->kind = kind;
    r->actor = actor;
    r->room_no = room_no;
    r->subject = subject & 0xffffu;
    if (text_len > TEXT_CAP)
        text_len = TEXT_CAP;
    r->text_len = text_len;
    if (text_len && text)
        memcpy(r->text, text, text_len);

    JRNL_SEQ = (JRNL_SEQ + 1) & 0xffffu;
    if (JRNL_SEQ == 0)
        JRNL_SEQ = 1;
    JRNL_HEAD = (JRNL_HEAD + 1) % JRNL_MAX;
    if (JRNL_FILL < JRNL_MAX)
        JRNL_FILL++;
}

struct stay *stay_find(uint32_t handle)
{
    if (handle == 0 || handle > STAY_MAX)
        return NULL;
    if (STAYS[handle - 1].state == 0)
        return NULL;
    return &STAYS[handle - 1];
}

struct cred *cred_find(uint32_t id)
{
    uint32_t i;
    for (i = 0; i < CRED_MAX; i++) {
        if (CREDS[i].id != 0 && CREDS[i].id == id)
            return &CREDS[i];
    }
    return NULL;
}

struct door *door_find(uint16_t id)
{
    if (id == 0 || id > DOOR_MAX)
        return NULL;
    if (DOORS[id - 1].id != id)
        return NULL;
    return &DOORS[id - 1];
}

struct zone *zone_find(uint8_t id)
{
    if (id == 0 || id > ZONE_MAX)
        return NULL;
    if ((ZONES[id - 1].flags & 0x01) == 0)
        return NULL;
    return &ZONES[id - 1];
}

struct staff *staff_find(uint16_t id)
{
    uint32_t i;
    for (i = 0; i < STAFF_MAX; i++) {
        if (STAFF[i].id != 0 && STAFF[i].id == id)
            return &STAFF[i];
    }
    return NULL;
}

struct swin *swin_find(uint8_t id)
{
    if (id == 0 || id > SCHED_MAX)
        return NULL;
    if (!SCHED[id - 1].in_use)
        return NULL;
    return &SCHED[id - 1];
}
