#include "kexd.h"
#include <errno.h>

/* ---- io ---- */

int read_full(int fd, void *dst, size_t n)
{
    uint8_t *p = (uint8_t *)dst;
    size_t got = 0;

    while (got < n) {
        ssize_t r = read(fd, p + got, n - got);
        if (r == 0)
            return -1;
        if (r < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        got += (size_t)r;
    }
    return 0;
}

int write_full(int fd, const void *src, size_t n)
{
    const uint8_t *p = (const uint8_t *)src;
    size_t sent = 0;

    while (sent < n) {
        ssize_t r = write(fd, p + sent, n - sent);
        if (r < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        sent += (size_t)r;
    }
    return 0;
}

int send_frame(int fd, uint8_t op, const uint8_t *body, size_t len)
{
    uint8_t hdr[8];

    hdr[0] = KX_MAGIC0;
    hdr[1] = KX_MAGIC1;
    hdr[2] = KX_MAGIC2;
    hdr[3] = KX_MAGIC3;
    hdr[4] = op;
    hdr[5] = KX_RESP_BIT;
    hdr[6] = (uint8_t)(len & 0xff);
    hdr[7] = (uint8_t)((len >> 8) & 0xff);
    if (write_full(fd, hdr, sizeof hdr) < 0)
        return -1;
    if (len && write_full(fd, body, len) < 0)
        return -1;
    return 0;
}

int send_status(int fd, uint8_t op, uint8_t st)
{
    return send_frame(fd, op, &st, 1);
}

void put_u16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v & 0xff);
    p[1] = (uint8_t)((v >> 8) & 0xff);
}

void put_u32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v & 0xff);
    p[1] = (uint8_t)((v >> 8) & 0xff);
    p[2] = (uint8_t)((v >> 16) & 0xff);
    p[3] = (uint8_t)((v >> 24) & 0xff);
}

uint16_t get_u16(const uint8_t *p)
{
    return (uint16_t)(p[0] | ((uint16_t)p[1] << 8));
}

uint32_t get_u32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

uint64_t fold64(const uint8_t *p, size_t n, uint64_t h)
{
    size_t i;

    for (i = 0; i < n; i++) {
        h ^= (uint64_t)p[i];
        h *= 0x100000001b3ULL;
    }
    return h;
}
