#include "kexd.h"

/* ---- credentials ---- */

void cred_blob(struct cred *c)
{
    uint8_t seed[16];
    uint64_t mix;
    int i;

    put_u32(seed + 0, c->owner);
    put_u32(seed + 4, (uint32_t)c->room_no);
    put_u32(seed + 8, c->id);
    put_u32(seed + 12, DEV.build);
    mix = fold64(seed, sizeof seed, SUBKEY);
    mix = fold64((const uint8_t *)&mix, sizeof mix, mix ^ 0xcbf29ce484222325ULL);
    for (i = 0; i < 8; i++)
        c->blob[i] = (uint8_t)((mix >> (8 * i)) & 0xff);
}

void cred_void_one(struct cred *c)
{
    c->flags = (uint8_t)((c->flags & ~0x01u) | 0x02u);
}

uint16_t cred_card_no(const struct cred *c, char *out, size_t cap)
{
    int r = snprintf(out, cap, "TK%03u-%04u-%04u-%04u",
                     (unsigned)(DEV.build % 1000u), (unsigned)(c->id % 10000u),
                     (unsigned)c->room_no, (unsigned)(c->expires % 10000u));
    if (r < 0)
        return 0;
    if ((size_t)r > cap - 1)
        r = (int)(cap - 1);
    return (uint16_t)r;
}

static void note_add(uint8_t kind, uint8_t reason, uint32_t pick, uint8_t actor,
                     uint16_t room, uint32_t subject)
{
    const uint8_t *nt = pool_note_at(note_index(kind, reason, pick));
    jrnl_add(kind, actor, room, subject, nt,
             (uint8_t)strnlen((const char *)nt, 40));
}

static int in_window(uint8_t days, uint16_t s, uint16_t e, uint32_t at)
{
    uint32_t mins = (at / 60u) % 1440u;
    uint32_t dow = (at / 86400u) % 7u;

    if (days == 0 || s == e)
        return 0;
    if (s < e) {
        if (!(mins >= s && mins < e))
            return 0;
    } else {
        if (mins < s && mins >= e)
            return 0;
        if (mins < s)
            dow = (dow + 6u) % 7u;
    }
    return (days >> dow) & 1u;
}

static struct cred *cred_alloc(void)
{
    uint32_t i;

    for (i = 0; i < CRED_MAX; i++)
        if (CREDS[i].id == 0)
            return &CREDS[i];
    return NULL;
}

static uint32_t cred_next_id(void)
{
    uint32_t id = CRED_SEQ;

    CRED_SEQ++;
    if (CRED_SEQ > 0xfffeu)
        CRED_SEQ = CRED_ID_BASE;
    return id;
}

static int cred_reply(int fd, uint8_t op, const struct cred *c)
{
    uint8_t out[18];

    out[0] = ST_OK;
    put_u32(out + 1, c->id);
    memcpy(out + 5, c->blob, 8);
    put_u32(out + 13, c->expires);
    out[17] = c->seq;
    return send_frame(fd, op, out, sizeof out);
}

int h_cred_issue(int fd, const uint8_t *b, uint16_t len)
{
    struct stay *s;
    struct cred *c;
    uint8_t nlen;

    if (len < 5)
        return send_status(fd, OP_CRED_ISSUE, ST_BODY);
    nlen = b[4];
    if (nlen > NOTE_MAX_LEN || (uint16_t)(5 + nlen) != len)
        return send_status(fd, OP_CRED_ISSUE, ST_BODY);
    s = stay_find(get_u32(b));
    if (!s)
        return send_status(fd, OP_CRED_ISSUE, ST_NOENT);
    if (s->state != 1)
        return send_status(fd, OP_CRED_ISSUE, ST_STATE);
    c = cred_alloc();
    if (!c)
        return send_status(fd, OP_CRED_ISSUE, ST_FULL);

    memset(c, 0, sizeof *c);
    c->id = cred_next_id();
    c->owner = s->handle;
    c->issued = dev_seconds();
    c->expires = s->check_out;
    c->room_no = s->room_no;
    c->zone_mask = guest_zone_mask(s->room_no);
    c->klass = 1;
    c->flags = 0x01;
    c->seq = 1;
    cred_blob(c);
    s->cred_count++;
    SESS_ISSUED++;

    jrnl_add(5, 0, s->room_no, c->id, b + 5, nlen);
    return cred_reply(fd, OP_CRED_ISSUE, c);
}

int h_cred_reissue(int fd, const uint8_t *b, uint16_t len)
{
    struct cred *old, *c;
    uint8_t nlen;

    if (len < 5)
        return send_status(fd, OP_CRED_REISSUE, ST_BODY);
    nlen = b[4];
    if (nlen > NOTE_MAX_LEN || (uint16_t)(5 + nlen) != len)
        return send_status(fd, OP_CRED_REISSUE, ST_BODY);
    old = cred_find(get_u32(b));
    if (!old)
        return send_status(fd, OP_CRED_REISSUE, ST_NOENT);
    if ((old->flags & 0x01) == 0)
        return send_status(fd, OP_CRED_REISSUE, ST_STATE);
    c = cred_alloc();
    if (!c)
        return send_status(fd, OP_CRED_REISSUE, ST_FULL);

    memset(c, 0, sizeof *c);
    c->id = cred_next_id();
    c->owner = old->owner;
    c->issued = dev_seconds();
    c->expires = old->expires;
    c->room_no = old->room_no;
    c->zone_mask = old->zone_mask;
    c->klass = old->klass;
    c->flags = 0x01;
    c->seq = (uint8_t)(old->seq + 1);
    cred_blob(c);
    cred_void_one(old);
    SESS_ISSUED++;

    jrnl_add(6, 0, c->room_no, c->id, b + 5, nlen);
    return cred_reply(fd, OP_CRED_REISSUE, c);
}

int h_cred_void(int fd, const uint8_t *b, uint16_t len)
{
    struct cred *c;
    uint8_t out[6];

    if (len != 4)
        return send_status(fd, OP_CRED_VOID, ST_BODY);
    c = cred_find(get_u32(b));
    if (!c)
        return send_status(fd, OP_CRED_VOID, ST_NOENT);
    if ((c->flags & 0x01) == 0)
        return send_status(fd, OP_CRED_VOID, ST_STATE);

    cred_void_one(c);
    SESS_VOIDED++;
    note_add(7, 0, c->id, 0, c->room_no, c->id);

    out[0] = ST_OK;
    put_u32(out + 1, c->id);
    out[5] = 1;
    return send_frame(fd, OP_CRED_VOID, out, sizeof out);
}

int h_cred_get(int fd, const uint8_t *b, uint16_t len)
{
    struct cred *c;
    uint8_t out[54];
    char cn[CARD_NO_LEN + 2];
    uint16_t cl;

    if (len != 4)
        return send_status(fd, OP_CRED_GET, ST_BODY);
    c = cred_find(get_u32(b));
    if (!c)
        return send_status(fd, OP_CRED_GET, ST_NOENT);

    memset(out, 0, sizeof out);
    memset(cn, 0, sizeof cn);
    cl = cred_card_no(c, cn, sizeof cn);
    out[0] = ST_OK;
    put_u32(out + 1, c->id);
    put_u32(out + 5, c->owner);
    out[9] = c->klass;
    out[10] = c->flags;
    out[11] = c->seq;
    out[12] = 0;
    put_u16(out + 13, c->room_no);
    put_u16(out + 15, c->zone_mask);
    put_u32(out + 17, c->issued);
    put_u32(out + 21, c->expires);
    memcpy(out + 25, c->blob, 8);
    out[33] = (uint8_t)cl;
    memcpy(out + 34, cn, CARD_NO_LEN + 1);
    return send_frame(fd, OP_CRED_GET, out, 54);
}

int h_cred_list(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[4 + LIST_CAP * 10];
    uint32_t owner, i, total = 0, seen = 0;
    uint8_t first, count, ret = 0;

    if (len != 6)
        return send_status(fd, OP_CRED_LIST, ST_BODY);
    owner = get_u32(b);
    first = b[4];
    count = b[5];
    if (count > LIST_CAP)
        return send_status(fd, OP_CRED_LIST, ST_BODY);

    for (i = 0; i < CRED_MAX; i++)
        if (CREDS[i].id != 0 && CREDS[i].owner == owner)
            total++;
    for (i = 0; i < CRED_MAX && ret < count; i++) {
        struct cred *c = &CREDS[i];
        uint8_t *p;
        if (c->id == 0 || c->owner != owner)
            continue;
        if (seen++ < first)
            continue;
        p = out + 4 + 10 * ret;
        put_u32(p, c->id);
        p[4] = c->klass;
        p[5] = c->flags;
        put_u32(p + 6, c->expires);
        ret++;
    }
    out[0] = ST_OK;
    out[1] = ret;
    put_u16(out + 2, (uint16_t)total);
    return send_frame(fd, OP_CRED_LIST, out, 4 + (size_t)ret * 10);
}

int h_cred_verify(int fd, const uint8_t *b, uint16_t len)
{
    struct cred *c;
    struct door *d;
    struct zone *z;
    uint8_t out[7];
    uint8_t verdict = 0, reason = 1, diff = 0;
    uint16_t door;
    uint32_t at, i;

    if (len != 18)
        return send_status(fd, OP_CRED_VERIFY, ST_BODY);
    door = get_u16(b + 12);
    at = get_u32(b + 14);
    if (at == 0)
        at = dev_seconds();
    d = door_find(door);
    if (!d)
        return send_status(fd, OP_CRED_VERIFY, ST_NOENT);
    z = zone_find(d->zone);

    c = cred_find(get_u32(b));
    if (c) {
        for (i = 0; i < 8; i++)
            diff |= (uint8_t)(c->blob[i] ^ b[4 + i]);
        if (diff)
            reason = 2;
        else if ((c->flags & 0x02) || (c->flags & 0x01) == 0)
            reason = 3;
        else if (at > c->expires)
            reason = 4;
        else if (d->flags & 0x08)
            reason = 8;
        else if (z && (z->flags & 0x02))
            reason = 6;
        else if (!(c->zone_mask & (uint16_t)(1u << ((d->zone - 1) & 15))) &&
                 !(c->room_no != 0 && c->room_no == d->room_no))
            reason = 5;
        else {
            uint32_t mins = (at / 60u) % 1440u;
            struct staff *p = c->klass == 1 ? NULL :
                (c->owner >= 40000u ? staff_find((uint16_t)(c->owner - 40000u))
                                    : NULL);
            if (z && (z->flags & 0x04) && c->klass == 1 &&
                z->curfew_start != z->curfew_end &&
                ((z->curfew_start < z->curfew_end &&
                  mins >= z->curfew_start && mins < z->curfew_end) ||
                 (z->curfew_start > z->curfew_end &&
                  (mins >= z->curfew_start || mins < z->curfew_end))))
                reason = 7;
            else if (p && !in_window(p->days, p->start_min, p->end_min, at))
                reason = 7;
            else {
                verdict = 1;
                reason = 0;
            }
        }
    }

    if (!verdict)
        note_add(8, reason, 0, 0, d->room_no, c ? c->id : 0);

    out[0] = ST_OK;
    out[1] = verdict;
    out[2] = reason;
    put_u16(out + 3, door);
    out[5] = d->zone;
    out[6] = 0;
    return send_frame(fd, OP_CRED_VERIFY, out, sizeof out);
}

int h_staff_cred_issue(int fd, const uint8_t *b, uint16_t len)
{
    struct staff *p;
    struct cred *c;
    uint16_t sid, zm;
    uint8_t days, nlen;

    if (len < 6)
        return send_status(fd, OP_STAFF_CRED_ISSUE, ST_BODY);
    sid = get_u16(b);
    zm = get_u16(b + 2);
    days = b[4];
    nlen = b[5];
    if (nlen > NOTE_MAX_LEN || (uint16_t)(6 + nlen) != len)
        return send_status(fd, OP_STAFF_CRED_ISSUE, ST_BODY);
    if (days < 1)
        return send_status(fd, OP_STAFF_CRED_ISSUE, ST_BODY);
    p = staff_find(sid);
    if (!p)
        return send_status(fd, OP_STAFF_CRED_ISSUE, ST_NOENT);
    if ((p->flags & 0x01) == 0)
        return send_status(fd, OP_STAFF_CRED_ISSUE, ST_STATE);
    if (zm & ~p->zone_mask)
        return send_status(fd, OP_STAFF_CRED_ISSUE, ST_DENY);
    c = cred_alloc();
    if (!c)
        return send_status(fd, OP_STAFF_CRED_ISSUE, ST_FULL);

    memset(c, 0, sizeof *c);
    c->id = cred_next_id();
    c->owner = 40000u + p->id;
    c->issued = dev_seconds();
    c->expires = c->issued + (uint32_t)days * 86400u;
    c->room_no = 0;
    c->zone_mask = zm;
    c->klass = p->klass == 4 ? 3 : (p->klass == 2 ? 4 : 2);
    c->flags = 0x01;
    c->seq = 1;
    cred_blob(c);
    p->cred_count++;
    SESS_ISSUED++;

    jrnl_add(9, (uint8_t)(p->id & 0xff), 0, c->id, b + 6, nlen);
    return cred_reply(fd, OP_STAFF_CRED_ISSUE, c);
}
