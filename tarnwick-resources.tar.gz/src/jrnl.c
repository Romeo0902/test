#include "kexd.h"

/* ---- journal ---- */

int h_jrnl_count(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[7];
    uint32_t i, oldest = 0, newest = 0;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_JRNL_COUNT, ST_BODY);
    for (i = 0; i < JRNL_FILL; i++) {
        uint32_t id = JRNL[i].id;
        if (JRNL[i].kind == 0)
            continue;
        if (oldest == 0 || id < oldest)
            oldest = id;
        if (id > newest)
            newest = id;
    }
    out[0] = ST_OK;
    put_u16(out + 1, (uint16_t)JRNL_FILL);
    put_u16(out + 3, (uint16_t)oldest);
    put_u16(out + 5, (uint16_t)newest);
    return send_frame(fd, OP_JRNL_COUNT, out, sizeof out);
}

int h_jrnl_get(int fd, const uint8_t *b, uint16_t len)
{
    struct jrec *r;
    uint8_t out[17 + TEXT_CAP];

    if (len != 4)
        return send_status(fd, OP_JRNL_GET, ST_BODY);
    r = jrnl_find(get_u32(b));
    if (!r)
        return send_status(fd, OP_JRNL_GET, ST_NOENT);

    out[0] = ST_OK;
    put_u32(out + 1, r->id);
    put_u32(out + 5, r->ts);
    out[9] = r->kind;
    out[10] = r->actor;
    put_u16(out + 11, r->room_no);
    put_u32(out + 13, r->subject);
    out[17] = r->text_len;
    if (r->text_len)
        memcpy(out + 18, r->text, r->text_len);
    return send_frame(fd, OP_JRNL_GET, out, 18 + (size_t)r->text_len);
}

int h_jrnl_find(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[2 + FIND_CAP * 4];
    uint8_t kind, limit, ret = 0;
    uint16_t room;
    uint32_t from, to, i;

    if (len != 12)
        return send_status(fd, OP_JRNL_FIND, ST_BODY);
    kind = b[0];
    room = get_u16(b + 1);
    from = get_u32(b + 3);
    to = get_u32(b + 7);
    limit = b[11];
    if (kind > 14 || limit > FIND_CAP)
        return send_status(fd, OP_JRNL_FIND, ST_BODY);
    if (to == 0)
        to = 0xffffffffu;

    for (i = 0; i < JRNL_FILL && ret < limit; i++) {
        struct jrec *r = &JRNL[i];
        if (r->kind == 0)
            continue;
        if (kind != 0 && r->kind != kind)
            continue;
        if (room != 0 && r->room_no != room)
            continue;
        if (r->ts < from || r->ts > to)
            continue;
        put_u32(out + 2 + 4 * ret, r->id);
        ret++;
    }
    out[0] = ST_OK;
    out[1] = ret;
    return send_frame(fd, OP_JRNL_FIND, out, 2 + (size_t)ret * 4);
}

int h_jrnl_peek(int fd, const uint8_t *b, uint16_t len)
{
    struct jrec *r;
    char line[512];
    uint8_t out[3 + 512];
    uint16_t n;

    if (len != 4)
        return send_status(fd, OP_JRNL_PEEK, ST_BODY);
    r = jrnl_find(get_u32(b));
    if (!r)
        return send_status(fd, OP_JRNL_PEEK, ST_NOENT);

    n = jrnl_peek_line(r, line, sizeof line);
    out[0] = ST_OK;
    put_u16(out + 1, n);
    memcpy(out + 3, line, n);
    return send_frame(fd, OP_JRNL_PEEK, out, 3 + (size_t)n);
}

int h_export_begin(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[5];
    uint32_t rendered = 0;
    uint16_t n, i;

    if (len < 1)
        return send_status(fd, OP_EXPORT_BEGIN, ST_BODY);
    n = b[0];
    if (n > REC_SLOTS || (uint16_t)(1 + 4 * n) != len)
        return send_status(fd, OP_EXPORT_BEGIN, ST_BODY);

    region_reset();
    for (i = 0; i < n; i++) {
        struct jrec *r = jrnl_find(get_u32(b + 1 + 4 * (size_t)i));
        if (!r)
            continue;
        if (jrnl_emit(r))
            break;
        EXP.rec_end[rendered] = (uint16_t)(EXP.put - EXP.buf);
        rendered++;
    }
    EXP.records_rendered = rendered;
    EXP.records_skipped = n - rendered;

    out[0] = ST_OK;
    put_u16(out + 1, (uint16_t)rendered);
    put_u16(out + 3, (uint16_t)(n - rendered));
    return send_frame(fd, OP_EXPORT_BEGIN, out, sizeof out);
}

int h_export_fetch(int fd, const uint8_t *b, uint16_t len)
{
    uint32_t want, avail;
    uint8_t out[3 + FETCH_CAP];

    if (len != 2)
        return send_status(fd, OP_EXPORT_FETCH, ST_BODY);

    want = get_u16(b);
    avail = (uint32_t)(EXP.put - EXP.get);
    if (want > avail)
        want = avail;
    if (want > FETCH_CAP)
        want = FETCH_CAP;

    out[0] = ST_OK;
    put_u16(out + 1, (uint16_t)want);
    if (want)
        memcpy(out + 3, EXP.get, want);
    EXP.get += want;
    if (EXP.get < EXP.buf || EXP.get > EXP.put)
        EXP.get = EXP.put;
    return send_frame(fd, OP_EXPORT_FETCH, out, 3 + (size_t)want);
}

int h_export_stat(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[11];

    (void)b;
    if (len != 0)
        return send_status(fd, OP_EXPORT_STAT, ST_BODY);
    out[0] = ST_OK;
    put_u16(out + 1, (uint16_t)EXP.records_rendered);
    put_u16(out + 3, (uint16_t)EXP.records_skipped);
    put_u16(out + 5, region_remaining());
    put_u32(out + 7, EXP.batch_seq);
    return send_frame(fd, OP_EXPORT_STAT, out, sizeof out);
}
