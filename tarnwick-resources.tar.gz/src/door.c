#include "kexd.h"

/* ---- lock map ---- */

int h_door_list(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[4 + LIST_CAP * 8];
    uint16_t first;
    uint8_t count, ret = 0;
    uint32_t i, total = 0, seen = 0;

    if (len != 3)
        return send_status(fd, OP_DOOR_LIST, ST_BODY);
    first = get_u16(b);
    count = b[2];
    if (count > LIST_CAP)
        return send_status(fd, OP_DOOR_LIST, ST_BODY);

    total = doors_provisioned();
    for (i = 0; i < DOOR_MAX && ret < count; i++) {
        struct door *d = &DOORS[i];
        uint8_t *p;
        if (d->id == 0)
            continue;
        if (seen++ < first)
            continue;
        p = out + 4 + 8 * ret;
        put_u16(p, d->id);
        put_u16(p + 2, d->room_no);
        p[4] = d->zone;
        p[5] = d->flags;
        p[6] = d->model;
        p[7] = d->battery;
        ret++;
    }
    out[0] = ST_OK;
    out[1] = ret;
    put_u16(out + 2, (uint16_t)total);
    return send_frame(fd, OP_DOOR_LIST, out, 4 + (size_t)ret * 8);
}

int h_door_get(int fd, const uint8_t *b, uint16_t len)
{
    struct door *d;
    uint8_t out[26 + BUS_LEN];
    size_t bl;

    if (len != 2)
        return send_status(fd, OP_DOOR_GET, ST_BODY);
    d = door_find(get_u16(b));
    if (!d)
        return send_status(fd, OP_DOOR_GET, ST_NOENT);

    memset(out, 0, sizeof out);
    bl = d->bus_len > BUS_LEN ? BUS_LEN : d->bus_len;
    out[0] = ST_OK;
    put_u16(out + 1, d->id);
    put_u16(out + 3, d->room_no);
    out[5] = d->zone;
    out[6] = d->flags;
    out[7] = d->model;
    out[8] = d->fw;
    put_u32(out + 9, d->last_seen);
    out[13] = d->battery;
    out[14] = (uint8_t)strnlen((const char *)d->label, LABEL_LEN);
    memcpy(out + 15, d->label, LABEL_LEN);
    out[25] = (uint8_t)bl;
    memcpy(out + 26, d->bus, bl);
    return send_frame(fd, OP_DOOR_GET, out, 26 + bl);
}

int h_door_set_flags(int fd, const uint8_t *b, uint16_t len)
{
    struct door *d;
    uint8_t set, clr, out[4];
    const uint8_t mask = 0x2e;

    if (len != 4)
        return send_status(fd, OP_DOOR_SET_FLAGS, ST_BODY);
    d = door_find(get_u16(b));
    if (!d)
        return send_status(fd, OP_DOOR_SET_FLAGS, ST_NOENT);
    set = b[2];
    clr = b[3];
    if ((set & ~mask) || (clr & ~mask))
        return send_status(fd, OP_DOOR_SET_FLAGS, ST_BODY);

    d->flags = (uint8_t)((d->flags | set) & ~clr);
    d->flags |= 0x01;
    {
        uint8_t touched = (uint8_t)(set | clr);
        uint32_t pick = (touched & 0x20) ? 0u : ((touched & 0x10) ? 1u : 2u);
        const uint8_t *nt = pool_note_at(note_index(10, 0, pick));
        jrnl_add(10, 0, d->room_no, d->id, nt,
                 (uint8_t)strnlen((const char *)nt, 40));
    }

    out[0] = ST_OK;
    put_u16(out + 1, d->id);
    out[3] = d->flags;
    return send_frame(fd, OP_DOOR_SET_FLAGS, out, sizeof out);
}

int h_zone_list(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[2 + ZONE_MAX * 8];
    uint8_t n = 0;
    uint32_t i;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_ZONE_LIST, ST_BODY);
    for (i = 0; i < ZONE_MAX; i++) {
        struct zone *z = &ZONES[i];
        uint8_t *p;
        if ((z->flags & 0x01) == 0)
            continue;
        p = out + 2 + 8 * n;
        p[0] = z->id;
        p[1] = z->flags;
        put_u16(p + 2, z->door_count);
        put_u16(p + 4, z->curfew_start);
        put_u16(p + 6, z->curfew_end);
        n++;
    }
    out[0] = ST_OK;
    out[1] = n;
    return send_frame(fd, OP_ZONE_LIST, out, 2 + (size_t)n * 8);
}

int h_zone_get(int fd, const uint8_t *b, uint16_t len)
{
    struct zone *z;
    uint8_t out[34];

    if (len != 1)
        return send_status(fd, OP_ZONE_GET, ST_BODY);
    z = zone_find(b[0]);
    if (!z)
        return send_status(fd, OP_ZONE_GET, ST_NOENT);

    memset(out, 0, sizeof out);
    out[0] = ST_OK;
    out[1] = z->id;
    out[2] = z->flags;
    put_u16(out + 3, z->door_count);
    put_u16(out + 5, z->curfew_start);
    put_u16(out + 7, z->curfew_end);
    out[9] = (uint8_t)strnlen((const char *)z->name, ZONE_NAME_LEN);
    memcpy(out + 10, z->name, ZONE_NAME_LEN);
    return send_frame(fd, OP_ZONE_GET, out, 34);
}

int h_zone_lockdown(int fd, const uint8_t *b, uint16_t len)
{
    struct zone *z;
    uint8_t on, out[5];
    uint16_t n = 0;
    uint32_t i;

    if (len != 2)
        return send_status(fd, OP_ZONE_LOCKDOWN, ST_BODY);
    on = b[1];
    if (on > 1)
        return send_status(fd, OP_ZONE_LOCKDOWN, ST_BODY);
    z = zone_find(b[0]);
    if (!z)
        return send_status(fd, OP_ZONE_LOCKDOWN, ST_NOENT);

    if (on)
        z->flags |= 0x02;
    else
        z->flags = (uint8_t)(z->flags & ~0x02u);
    for (i = 0; i < DOOR_MAX; i++) {
        struct door *d = &DOORS[i];
        if (d->id == 0 || d->zone != z->id)
            continue;
        if (on)
            d->flags |= 0x40;
        else
            d->flags = (uint8_t)(d->flags & ~0x40u);
        n++;
    }
    jrnl_add(11, 0, 0, z->id, z->name,
             (uint8_t)strnlen((const char *)z->name, ZONE_NAME_LEN));

    out[0] = ST_OK;
    out[1] = z->id;
    out[2] = z->flags;
    put_u16(out + 3, n);
    return send_frame(fd, OP_ZONE_LOCKDOWN, out, sizeof out);
}

static void swin_pack(uint8_t *p, const struct swin *w)
{
    p[0] = w->id;
    p[1] = w->zone;
    p[2] = w->mode;
    p[3] = w->days;
    put_u16(p + 4, w->start_min);
    put_u16(p + 6, w->end_min);
    put_u32(p + 8, swin_hits(w));
}

int h_sched_list(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[2 + SCHED_MAX * 12];
    uint8_t n = 0;
    uint32_t i;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_SCHED_LIST, ST_BODY);
    for (i = 0; i < SCHED_MAX; i++) {
        if (!SCHED[i].in_use)
            continue;
        swin_pack(out + 2 + 12 * n, &SCHED[i]);
        n++;
    }
    out[0] = ST_OK;
    out[1] = n;
    return send_frame(fd, OP_SCHED_LIST, out, 2 + (size_t)n * 12);
}

int h_sched_set(int fd, const uint8_t *b, uint16_t len)
{
    struct swin *w = NULL;
    uint8_t id, zone, mode, days, out[13];
    uint16_t s, e;
    uint32_t i;

    if (len != 8)
        return send_status(fd, OP_SCHED_SET, ST_BODY);
    id = b[0];
    zone = b[1];
    mode = b[2];
    days = b[3];
    s = get_u16(b + 4);
    e = get_u16(b + 6);
    if (id > SCHED_MAX || mode < 1 || mode > 3 || (days & 0x80))
        return send_status(fd, OP_SCHED_SET, ST_BODY);
    if (s > 1439 || e > 1439 || s == e)
        return send_status(fd, OP_SCHED_SET, ST_BODY);
    if (!zone_find(zone))
        return send_status(fd, OP_SCHED_SET, ST_NOENT);

    if (id == 0) {
        for (i = 0; i < SCHED_MAX; i++)
            if (!SCHED[i].in_use) {
                w = &SCHED[i];
                w->id = (uint8_t)(i + 1);
                w->hits = 0;
                break;
            }
        if (!w)
            return send_status(fd, OP_SCHED_SET, ST_FULL);
    } else {
        w = &SCHED[id - 1];
        if (!w->in_use) {
            w->id = id;
            w->hits = 0;
        }
    }

    w->zone = zone;
    w->mode = mode;
    w->days = days;
    w->start_min = s;
    w->end_min = e;
    w->in_use = 1;
    jrnl_add(12, 0, 0, w->id, NULL, 0);

    out[0] = ST_OK;
    swin_pack(out + 1, w);
    return send_frame(fd, OP_SCHED_SET, out, sizeof out);
}

int h_door_export(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[5];
    uint32_t rendered = 0;
    uint16_t n, i;

    if (len < 1)
        return send_status(fd, OP_DOOR_EXPORT, ST_BODY);
    n = b[0];
    if (n > REC_SLOTS || (uint16_t)(1 + 2 * n) != len)
        return send_status(fd, OP_DOOR_EXPORT, ST_BODY);

    region_reset();
    for (i = 0; i < n; i++) {
        struct door *d = door_find(get_u16(b + 1 + 2 * (size_t)i));
        if (!d)
            continue;
        if (door_emit(d))
            break;
        EXP.rec_end[rendered] = (uint16_t)(EXP.put - EXP.buf);
        rendered++;
    }
    EXP.records_rendered = rendered;
    EXP.records_skipped = n - rendered;

    out[0] = ST_OK;
    put_u16(out + 1, (uint16_t)rendered);
    put_u16(out + 3, (uint16_t)(n - rendered));
    return send_frame(fd, OP_DOOR_EXPORT, out, sizeof out);
}
