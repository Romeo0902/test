#include "kexd.h"

/* ---- device ---- */

int h_hello(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[22];

    (void)b;
    if (len != 0)
        return send_status(fd, OP_HELLO, ST_BODY);
    out[0] = ST_OK;
    put_u16(out + 1, 220);
    put_u16(out + 3, DEV.hw_rev);
    put_u16(out + 5, 12);
    put_u32(out + 7, DEV.build);
    put_u32(out + 11, dev_uptime());
    put_u32(out + 15, stays_open());
    put_u16(out + 19, CAPS_BITS);
    return send_frame(fd, OP_HELLO, out, 21);
}

int h_devinfo(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[40];

    (void)b;
    if (len != 0)
        return send_status(fd, OP_DEVINFO, ST_BODY);
    memset(out, 0, sizeof out);
    out[0] = ST_OK;
    memcpy(out + 1, DEV.serial, 16);
    memcpy(out + 17, DEV.mac, 6);
    out[23] = DEV.fw_major;
    out[24] = DEV.fw_minor;
    out[25] = DEV.fw_patch;
    out[26] = DEV.hw_rev;
    put_u32(out + 27, DEV.build);
    put_u32(out + 31, (uint32_t)(BOOT_TS - SVC_BASE));
    put_u16(out + 35, CAPS_BITS);
    put_u16(out + 37, 0);
    return send_frame(fd, OP_DEVINFO, out, 39);
}

static int clock_reply(int fd, uint8_t op)
{
    uint8_t out[18];

    out[0] = ST_OK;
    put_u32(out + 1, dev_seconds());
    put_u32(out + 5, (uint32_t)time(NULL));
    put_u16(out + 9, (uint16_t)TZ_MIN);
    out[11] = DST_ON;
    out[12] = (uint8_t)(int8_t)DRIFT_PPM;
    put_u32(out + 13, cnt_sync_age());
    return send_frame(fd, op, out, 17);
}

int h_clock_get(int fd, const uint8_t *b, uint16_t len)
{
    (void)b;
    if (len != 0)
        return send_status(fd, OP_CLOCK_GET, ST_BODY);
    return clock_reply(fd, OP_CLOCK_GET);
}

int h_clock_set(int fd, const uint8_t *b, uint16_t len)
{
    int16_t tz;
    uint8_t dst;
    const uint8_t *nt;

    if (len != 3)
        return send_status(fd, OP_CLOCK_SET, ST_BODY);
    tz = (int16_t)get_u16(b);
    dst = b[2];
    if (tz < -720 || tz > 840 || dst > 1)
        return send_status(fd, OP_CLOCK_SET, ST_BODY);
    TZ_MIN = tz;
    DST_ON = dst;
    nt = pool_note_at(note_index(13, 0, 0));
    jrnl_add(13, 0, 0, (uint32_t)(uint16_t)tz, nt,
             (uint8_t)strnlen((const char *)nt, 40));
    return clock_reply(fd, OP_CLOCK_SET);
}

int h_diag_selftest(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[2 + 8 * 4];
    const uint8_t *nt;
    uint8_t i;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_DIAG_SELFTEST, ST_BODY);
    out[0] = ST_OK;
    out[1] = 8;
    for (i = 0; i < 8; i++) {
        uint8_t *p = out + 2 + 4 * i;
        uint16_t detail = 0;
        uint8_t result = 0;
        switch (i + 1) {
        case 1: detail = (uint16_t)cnt_head_faults(); break;
        case 2: detail = (uint16_t)cnt_reader_temp(); break;
        case 3: detail = (uint16_t)cnt_sync_age(); break;
        case 4: detail = (uint16_t)JRNL_FILL; break;
        case 5: detail = (uint16_t)doors_online(); break;
        case 6: result = 1; detail = (uint16_t)doors_offline(); break;
        case 7: detail = (uint16_t)cnt_mains_events(); break;
        default: detail = 0; break;
        }
        p[0] = (uint8_t)(i + 1);
        p[1] = result;
        put_u16(p + 2, detail);
    }
    nt = pool_note_at(note_index(14, 0, 0));
    jrnl_add(14, 0, 0, 0, nt, (uint8_t)strnlen((const char *)nt, 40));
    return send_frame(fd, OP_DIAG_SELFTEST, out, sizeof out);
}

int h_diag_text(int fd, const uint8_t *b, uint16_t len)
{
    char txt[DIAG_CAP + 8];
    uint8_t out[3 + DIAG_CAP];
    size_t n = 0;
    uint32_t up = dev_uptime();
    uint32_t sv = dev_seconds();
    uint32_t enc = cnt_cards_encoded();
    uint32_t temp = cnt_reader_temp();
    int r;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_DIAG_TEXT, ST_BODY);

    r = snprintf(txt + n, sizeof txt - n, "TK-220 encoder fw %u.%u.%u build %08X",
                 DEV.fw_major, DEV.fw_minor, DEV.fw_patch, DEV.build);
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n, "\nuptime %u:%02u:%02u service %ud %02u:%02u:%02u",
                 up / 3600u, (up / 60u) % 60u, up % 60u, sv / 86400u,
                 (sv / 3600u) % 24u, (sv / 60u) % 60u, sv % 60u);
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n, "\nencoder head %u cycles %u faults",
                 cnt_head_cycles(), cnt_head_faults());
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n, "\ncards encoded %u voided %u",
                 enc, cnt_cards_voided());
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n,
                 "\ndoors %u provisioned %u online %u offline %u low battery",
                 doors_provisioned(), doors_online(), doors_offline(), doors_lowbatt());
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n, "\nzones %u in service %u lockdown",
                 zones_in_service(), zones_lockdown());
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n, "\nstays %u open %u closed",
                 stays_open(), stays_closed());
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n,
                 "\njournal %u records batch %u rendered %u skipped %u",
                 JRNL_FILL, EXP.batch_seq, EXP.records_rendered, EXP.records_skipped);
    n += (size_t)(r > 0 ? r : 0);
    r = snprintf(txt + n, sizeof txt - n, "\nreader %u.%uC mains %u resets %u",
                 temp / 10u, temp % 10u, cnt_mains_events(), cnt_reader_resets());
    n += (size_t)(r > 0 ? r : 0);

    if (n > DIAG_CAP)
        n = DIAG_CAP;
    out[0] = ST_OK;
    put_u16(out + 1, (uint16_t)n);
    memcpy(out + 3, txt, n);
    return send_frame(fd, OP_DIAG_TEXT, out, 3 + n);
}

int h_site_info(int fd, const uint8_t *b, uint16_t len)
{
    const struct siterec *r = site_rec();
    uint8_t out[165];
    size_t o = 0;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_SITE_INFO, ST_BODY);
    memset(out, 0, sizeof out);
    out[o++] = ST_OK;
    out[o] = (uint8_t)strnlen((const char *)r->name, SITE_NAME_LEN);
    memcpy(out + o + 1, r->name, SITE_NAME_LEN);
    o += 1 + SITE_NAME_LEN;
    out[o] = (uint8_t)strnlen((const char *)r->addr, SITE_ADDR_LEN);
    memcpy(out + o + 1, r->addr, SITE_ADDR_LEN);
    o += 1 + SITE_ADDR_LEN;
    out[o] = (uint8_t)strnlen((const char *)r->inst, SITE_INST_LEN);
    memcpy(out + o + 1, r->inst, SITE_INST_LEN);
    o += 1 + SITE_INST_LEN;
    out[o] = (uint8_t)strnlen((const char *)r->tick, SITE_TICK_LEN);
    memcpy(out + o + 1, r->tick, SITE_TICK_LEN);
    o += 1 + SITE_TICK_LEN;
    put_u32(out + o, (uint32_t)(BOOT_TS - SVC_BASE));
    put_u16(out + o + 4, r->site_id);
    put_u16(out + o + 6, 0);
    return send_frame(fd, OP_SITE_INFO, out, o + 8);
}

int h_counters(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[1 + 17 * 4];
    uint32_t v[17];
    int i;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_COUNTERS, ST_BODY);
    v[0] = dev_uptime();
    v[1] = dev_seconds();
    v[2] = cnt_cards_encoded();
    v[3] = cnt_cards_voided();
    v[4] = cnt_head_cycles();
    v[5] = cnt_head_faults();
    v[6] = cnt_mains_events();
    v[7] = cnt_reader_resets();
    v[8] = cnt_reader_temp();
    v[9] = doors_provisioned();
    v[10] = doors_online();
    v[11] = doors_offline();
    v[12] = doors_lowbatt();
    v[13] = zones_in_service();
    v[14] = zones_lockdown();
    v[15] = stays_open();
    v[16] = stays_closed();
    out[0] = ST_OK;
    for (i = 0; i < 17; i++)
        put_u32(out + 1 + 4 * i, v[i]);
    return send_frame(fd, OP_COUNTERS, out, sizeof out);
}
