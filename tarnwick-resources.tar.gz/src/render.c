#include "kexd.h"

/* ---- export ---- */

static char hex_digit(uint8_t v)
{
    v &= 0x0f;
    return (char)(v < 10 ? '0' + v : 'A' + (v - 10));
}

void region_reset(void)
{
    EXP.get = EXP.buf;
    EXP.put = EXP.buf;
    EXP.batch_seq++;
    memset(EXP.rec_end, 0, sizeof EXP.rec_end);
}

uint16_t region_remaining(void)
{
    size_t off = (size_t)(EXP.get - EXP.buf);
    uint32_t i, n = 0;

    for (i = 0; i < EXP.records_rendered && i < REC_SLOTS; i++)
        if ((size_t)EXP.rec_end[i] > off)
            n++;
    return (uint16_t)n;
}

/*
 * Render one journal line for the PMS import: fixed fields, then the note
 * field, which runs to end of line.  Bytes the importer cannot take literally
 * are rewritten in its numeric form.
 */
__attribute__((noinline)) int jrnl_emit(const struct jrec *r)
{
    size_t used = (size_t)(EXP.put - EXP.buf);
    size_t need = 24 + 2 * (size_t)r->text_len;
    char head[32];
    int hl;
    uint8_t i;

    if (used + need > sizeof(EXP.buf))
        return 1;

    if (EXP.put != EXP.buf)
        *EXP.put++ = '\n';

    hl = snprintf(head, sizeof head, "%u,%u,%u,%u,",
                  (unsigned)r->id, (unsigned)r->kind,
                  (unsigned)r->room_no, (unsigned)r->subject);
    if (hl < 0)
        hl = 0;
    if (hl > (int)sizeof head - 1)
        hl = (int)sizeof head - 1;
    memcpy(EXP.put, head, (size_t)hl);
    EXP.put += hl;

    for (i = 0; i < r->text_len; i++) {
        uint8_t c = r->text[i];
        if (c == '"') {
            EXP.put[0] = '\\';
            EXP.put[1] = '"';
            EXP.put += 2;
        } else if (c == '\\') {
            EXP.put[0] = '\\';
            EXP.put[1] = '\\';
            EXP.put += 2;
        } else if (c >= 0x20 && c <= 0x7e) {
            *EXP.put++ = c;
        } else {
            EXP.put[0] = '\\';
            EXP.put[1] = (uint8_t)('0' + (c / 100));
            EXP.put[2] = (uint8_t)('0' + ((c / 10) % 10));
            EXP.put[3] = (uint8_t)('0' + (c % 10));
            EXP.put += 4;
        }
    }
    return 0;
}

/*
 * Render one door line for the PMS import: fixed fields, then the label and
 * bus status fields, which run to end of line.  Bytes the importer cannot take
 * literally are rewritten in its percent form.
 */
__attribute__((noinline)) int door_emit(const struct door *d)
{
    size_t used = (size_t)(EXP.put - EXP.buf);
    size_t llen = strnlen((const char *)d->label, LABEL_LEN);
    size_t blen = d->bus_len > BUS_LEN ? BUS_LEN : d->bus_len;
    size_t need = 24 + 3 * (llen + blen);
    char head[32];
    int hl;
    size_t i;

    if (used + need > sizeof(EXP.buf))
        return 1;

    if (EXP.put != EXP.buf)
        *EXP.put++ = '\n';

    hl = snprintf(head, sizeof head, "%u,%u,%u,%u,",
                  (unsigned)d->id, (unsigned)d->zone,
                  (unsigned)d->room_no, (unsigned)d->flags);
    if (hl < 0)
        hl = 0;
    if (hl > (int)sizeof head - 1)
        hl = (int)sizeof head - 1;
    memcpy(EXP.put, head, (size_t)hl);
    EXP.put += hl;

    for (i = 0; i < llen + blen + 1; i++) {
        uint8_t c;
        if (i == llen) {
            *EXP.put++ = ',';
            continue;
        }
        c = i < llen ? d->label[i] : d->bus[i - llen - 1];
        if (c >= 0x20 && c <= 0x7e && c != '%') {
            *EXP.put++ = c;
        } else {
            EXP.put[0] = '%';
            EXP.put[1] = (uint8_t)hex_digit((uint8_t)(c >> 4));
            EXP.put[2] = (uint8_t)hex_digit(c);
            EXP.put += 3;
        }
    }
    return 0;
}

__attribute__((noinline)) uint16_t jrnl_peek_line(const struct jrec *r,
                                                  char *out, size_t cap)
{
    size_t n;
    int hl;
    uint8_t i;

    if (cap < 2)
        return 0;
    hl = snprintf(out, cap, "%u,%u,%u,%u,",
                  (unsigned)r->id, (unsigned)r->kind,
                  (unsigned)r->room_no, (unsigned)r->subject);
    if (hl < 0)
        hl = 0;
    if ((size_t)hl > cap - 1)
        hl = (int)(cap - 1);
    n = (size_t)hl;

    for (i = 0; i < r->text_len; i++) {
        if (n + 2 > cap)
            break;
        out[n++] = hex_digit((uint8_t)(r->text[i] >> 4));
        out[n++] = hex_digit(r->text[i]);
    }
    return (uint16_t)n;
}
