#include "kexd.h"

/* ---- seeding ---- */

#define N_OPEN    30
#define N_CLOSED  22
#define N_STAYS   (N_OPEN + N_CLOSED)
#define ENC_MAX   320

static uint32_t LCG;

static uint32_t rnd(void)
{
    LCG = LCG * 1103515245u + 12345u;
    return (LCG >> 8) & 0x00ffffffu;
}

static uint16_t GUEST_ROOM[256];
static uint16_t GUEST_DOOR[256];
static uint16_t GUEST_N;

static uint32_t T0, T1, D0, D1;

struct encev {
    uint32_t ts;
    uint32_t id;
    uint8_t  kind;
    uint8_t  actor;
    uint8_t  live;
    uint8_t  klass;
    uint16_t room;
    uint32_t owner;
    uint32_t expires;
    uint16_t zone_mask;
};

static struct encev ENC[ENC_MAX];
static uint16_t ENC_N;

static void collect_rooms(void)
{
    uint32_t i;

    for (i = 0; i < DOOR_MAX && GUEST_N < 256; i++) {
        if (DOORS[i].id != 0 && DOORS[i].room_no != 0) {
            GUEST_ROOM[GUEST_N] = DOORS[i].room_no;
            GUEST_DOOR[GUEST_N] = DOORS[i].id;
            GUEST_N++;
        }
    }
}

uint16_t door_of_room(uint16_t room)
{
    uint16_t i;

    for (i = 0; i < GUEST_N; i++)
        if (GUEST_ROOM[i] == room)
            return GUEST_DOOR[i];
    return 0;
}

static uint32_t band_ts(uint32_t day, uint32_t lo_h, uint32_t hi_h)
{
    uint32_t span = (hi_h > lo_h ? hi_h - lo_h : 24u + hi_h - lo_h) * 3600u;

    return day * 86400u + lo_h * 3600u + rnd() % span;
}

static uint32_t span_band(uint32_t lo_h, uint32_t hi_h)
{
    uint32_t tries;

    for (tries = 0; tries < 24; tries++) {
        uint32_t ts = band_ts(D0 + rnd() % (D1 - D0 + 1u), lo_h, hi_h);
        if (ts >= T0 + 30u && ts <= T1 - 30u)
            return ts;
    }
    return T0 + 60u + rnd() % (T1 - T0 - 120u);
}

static void seed_zones(void)
{
    uint32_t i;

    for (i = 0; i < ZONE_MAX; i++)
        ZONES[i].door_count = 0;
    for (i = 0; i < DOOR_MAX; i++) {
        struct door *d = &DOORS[i];
        if (d->id != 0 && d->zone >= 1 && d->zone <= ZONE_MAX)
            ZONES[d->zone - 1].door_count++;
    }
}

static void seed_doors(void)
{
    uint32_t base = (uint32_t)SVC_BASE;
    uint32_t i;

    for (i = 0; i < DOOR_MAX; i++) {
        struct door *d = &DOORS[i];
        uint32_t r;
        if (d->id == 0)
            continue;
        r = rnd();
        if (d->zone == 8)
            d->model = (uint8_t)(4 - (r % 5u == 0 ? 1 : 0));
        else if (d->room_no != 0)
            d->model = (uint8_t)(r % 7u == 0 ? 2 : 1);
        else if (d->zone == 1 || d->zone == 9)
            d->model = (uint8_t)(r % 3u == 0 ? 2 : 3);
        else
            d->model = (uint8_t)(r % 4u == 0 ? 3 : 2);
        d->fw = (uint8_t)(0x21 + (rnd() % 4u) * 3u + (d->zone % 3u));
        if (d->flags & 0x10)
            d->battery = (uint8_t)(4 + rnd() % 16u);
        else
            d->battery = (uint8_t)(46 + rnd() % 55u);
        if (d->flags & 0x08)
            d->last_seen = base - (uint32_t)(7200 + rnd() % 160000u);
        else
            d->last_seen = base - (uint32_t)(rnd() % 1500u);
    }
}

static void seed_sched(void)
{
    uint32_t i;

    for (i = 0; i < SCHED_MAX; i++)
        if (SCHED[i].in_use)
            SCHED[i].hits = 60u + rnd() % 1400u;
}

static int room_taken(uint16_t room, uint32_t upto)
{
    uint32_t i;

    for (i = 0; i < upto; i++)
        if (STAYS[i].state != 0 && STAYS[i].room_no == room)
            return 1;
    return 0;
}

static void seed_stays(void)
{
    uint32_t base = (uint32_t)SVC_BASE;
    uint32_t i;

    for (i = 0; i < STAY_MAX; i++)
        memset(&STAYS[i], 0, sizeof STAYS[i]);

    for (i = 0; i < N_STAYS; i++) {
        struct stay *s = &STAYS[i];
        const uint8_t *nm = pool_name(i * 3 + 1);
        size_t nl = strnlen((const char *)nm, 24);
        uint16_t room = 0;
        uint32_t tries, nights, in_day;

        for (tries = 0; tries < 64; tries++) {
            uint16_t cand = GUEST_N ? GUEST_ROOM[rnd() % GUEST_N] : 0;
            if (!room_taken(cand, i)) {
                room = cand;
                break;
            }
        }
        s->handle = i + 1;
        s->room_no = room;
        s->party = (uint8_t)(1 + rnd() % 3u);
        s->name_len = (uint8_t)nl;
        memcpy(s->name, nm, nl);

        if (i < N_OPEN) {
            in_day = D0 - 4u + rnd() % 7u;
            if (in_day > D1)
                in_day = D1;
            s->state = 1;
            s->check_in = band_ts(in_day, 14, 22);
            if (s->check_in > base)
                s->check_in = base - 3600u - rnd() % 40000u;
            nights = (D1 + 1u > in_day ? D1 + 1u - in_day : 1u) + rnd() % 5u;
            s->check_out = band_ts(in_day + nights, 7, 11);
            while (s->check_out <= base + 3600u)
                s->check_out += 86400u;
        } else {
            uint32_t out_day = D0 + rnd() % (D1 - D0 + 1u);
            nights = 1u + rnd() % 4u;
            s->state = 2;
            s->check_out = band_ts(out_day, 7, 11);
            if (s->check_out < T0 + 60u)
                s->check_out = band_ts(out_day + 1u, 7, 11);
            if (s->check_out > T1 - 60u)
                s->check_out = band_ts(out_day - 1u, 7, 11);
            s->check_in = band_ts(out_day - nights, 14, 22);
        }
    }
}

static uint8_t staff_at(uint32_t pick)
{
    uint32_t i, seen = 0, total = 0;

    for (i = 0; i < STAFF_MAX; i++)
        if (STAFF[i].id != 0)
            total++;
    if (total == 0)
        return 0;
    pick %= total;
    for (i = 0; i < STAFF_MAX; i++) {
        if (STAFF[i].id == 0)
            continue;
        if (seen == pick)
            return (uint8_t)(STAFF[i].id & 0xff);
        seen++;
    }
    return 0;
}

static void enc_add(uint32_t ts, uint8_t kind, uint8_t actor, uint16_t room,
                    uint32_t owner, uint8_t live, uint8_t klass,
                    uint32_t expires, uint16_t zone_mask)
{
    struct encev *e;

    if (ENC_N >= ENC_MAX)
        return;
    e = &ENC[ENC_N++];
    e->ts = ts;
    e->kind = kind;
    e->actor = actor;
    e->room = room;
    e->owner = owner;
    e->live = live;
    e->klass = klass;
    e->expires = expires;
    e->zone_mask = zone_mask;
}

static struct stay *resident_at(uint32_t ts, uint32_t pick)
{
    uint32_t i, n = 0;

    for (i = 0; i < N_STAYS; i++)
        if (STAYS[i].check_in <= ts && ts <= STAYS[i].check_out)
            n++;
    if (n == 0)
        return &STAYS[pick % N_STAYS];
    pick %= n;
    n = 0;
    for (i = 0; i < N_STAYS; i++) {
        if (STAYS[i].check_in <= ts && ts <= STAYS[i].check_out) {
            if (n == pick)
                return &STAYS[i];
            n++;
        }
    }
    return &STAYS[0];
}

static uint8_t HAS_CARD[N_STAYS];

static struct stay *tick_owner(uint32_t ts, uint32_t pick)
{
    uint32_t i;

    for (i = 0; i < N_OPEN; i++) {
        struct stay *s = &STAYS[i];
        if (!HAS_CARD[i] && s->check_in >= T0 && s->check_in <= ts &&
            ts <= s->check_out)
            return s;
    }
    return resident_at(ts, pick);
}

static void build_encodes(void)
{
    uint32_t base = (uint32_t)SVC_BASE;
    uint32_t k, i, j;

    ENC_N = 0;
    memset(HAS_CARD, 0, sizeof HAS_CARD);

    for (k = T0 / 2404u + 1u; k * 2404u <= T1; k++) {
        uint32_t ts = k * 2404u;
        uint32_t r = k % 8u;
        if (r == 0) {
            uint8_t sid = staff_at(k * 7u);
            enc_add(ts, 9, sid, 0, 40000u + sid, 0, 0, 0, 0);
        } else {
            struct stay *s = tick_owner(ts, k * 13u);
            uint8_t live = (uint8_t)(s->state == 1 && s->check_out > base &&
                                     s->handle <= N_OPEN);
            if (s->handle >= 1 && s->handle <= N_STAYS)
                HAS_CARD[s->handle - 1] = 1;
            enc_add(ts, r == 5 ? 6 : 5, staff_at(k / 3u), s->room_no,
                    s->handle, live, 1, s->check_out,
                    guest_zone_mask(s->room_no));
        }
    }

    for (i = 0; i < N_OPEN; i++) {
        struct stay *s = &STAYS[i];
        uint32_t cards, ts;
        if (s->check_in >= T0)
            continue;
        cards = 1u + (s->party > 1 ? 1u : 0u);
        for (j = 0; j < cards; j++) {
            ts = s->check_in + 240u + j * 2400u + rnd() % 900u;
            if (ts >= T0)
                ts = T0 - 300u - rnd() % 40000u;
            enc_add(ts, 5, staff_at(i + j), s->room_no, s->handle, 1, 1,
                    s->check_out, guest_zone_mask(s->room_no));
        }
        HAS_CARD[i] = 1;
    }

    for (i = 0; i < STAFF_MAX; i++) {
        struct staff *p = &STAFF[i];
        uint32_t ts, exp;
        if (p->id == 0 || (i % 7u) == 3u)
            continue;
        ts = base - (uint32_t)(86400u * (6u + rnd() % 210u)) - rnd() % 60000u;
        exp = ts + 86400u * (180u + rnd() % 220u);
        if (exp <= base + 86400u)
            exp = base + 86400u * (14u + rnd() % 120u);
        enc_add(ts, 9, (uint8_t)(p->id & 0xff), 0, 40000u + p->id, 1,
                p->klass == 4 ? 3 : (p->klass == 2 ? 4 : 2), exp,
                p->zone_mask);
    }

    for (i = 0; i + 1 < ENC_N; i++) {
        uint32_t m = i;
        for (j = i + 1; j < ENC_N; j++)
            if (ENC[j].ts < ENC[m].ts)
                m = j;
        if (m != i) {
            struct encev tmp = ENC[i];
            ENC[i] = ENC[m];
            ENC[m] = tmp;
        }
    }
    for (i = 0; i < ENC_N; i++)
        ENC[i].id = CRED_ID_BASE + i;
    CRED_SEQ = CRED_ID_BASE + ENC_N;
}

static void seed_creds(void)
{
    uint32_t i, n = 0;

    for (i = 0; i < CRED_MAX; i++)
        memset(&CREDS[i], 0, sizeof CREDS[i]);

    for (i = 0; i < ENC_N && n < CRED_MAX; i++) {
        struct encev *e = &ENC[i];
        struct cred *c;
        if (!e->live)
            continue;
        c = &CREDS[n++];
        c->id = e->id;
        c->owner = e->owner;
        c->issued = e->ts;
        c->expires = e->expires;
        c->room_no = e->room;
        c->zone_mask = e->zone_mask;
        c->klass = e->klass;
        c->flags = 0x01;
        c->seq = (uint8_t)(1 + (i % 3u == 0 ? 1 : 0));
        cred_blob(c);
        if (e->room != 0) {
            struct stay *s = stay_find(e->owner);
            if (s)
                s->cred_count++;
        } else {
            struct staff *p = staff_find((uint16_t)(e->owner - 40000u));
            if (p)
                p->cred_count++;
        }
    }
}

static uint32_t JN;

static void ev(uint32_t ts, uint8_t kind, uint8_t actor, uint16_t room,
               uint32_t subj, const uint8_t *text, size_t tl)
{
    struct jrec *r;

    if (JN >= JRNL_MAX)
        return;
    r = &JRNL[JN++];
    memset(r, 0, sizeof *r);
    r->ts = ts;
    r->kind = kind;
    r->actor = actor;
    r->room_no = room;
    r->subject = subj & 0xffffu;
    if (tl > TEXT_CAP)
        tl = TEXT_CAP;
    r->text_len = (uint8_t)tl;
    if (tl && text)
        memcpy(r->text, text, tl);
}

static void ev_note(uint32_t ts, uint8_t kind, uint8_t reason, uint32_t pick,
                    uint8_t actor, uint16_t room, uint32_t subj)
{
    const uint8_t *n = pool_note_at(note_index(kind, reason, pick));
    ev(ts, kind, actor, room, subj, n, strnlen((const char *)n, 40));
}

static void seed_journal(void)
{
    uint32_t i;

    JN = 0;
    ev_note(T0, 8, 1, 0, 0, 0, 0);

    for (i = 0; i < ENC_N; i++) {
        struct encev *e = &ENC[i];
        if (e->ts < T0 || e->ts > T1)
            continue;
        if (e->kind == 9) {
            struct staff *p = staff_find((uint16_t)(e->owner - 40000u));
            const uint8_t *nm = p ? p->name : pool_name(i);
            ev(e->ts, 9, e->actor, 0, e->id, nm,
               strnlen((const char *)nm, STAFF_NAME_LEN));
        } else {
            ev_note(e->ts, e->kind, 0, i, e->actor, e->room, e->id);
        }
    }
    for (i = T0 / 9007u + 1u; i * 9007u <= T1; i++)
        ev_note(i * 9007u, 7, 0, i, staff_at(i), 0,
                CRED_ID_BASE + (i % (ENC_N ? ENC_N : 1u)));
    for (i = T0 / 86400u + 1u; i * 86400u <= T1; i++)
        ev_note(i * 86400u, 14, 0, 0, 0, 0, 0);

    for (i = 0; i < N_STAYS; i++) {
        struct stay *s = &STAYS[i];
        if (s->check_in >= T0 && s->check_in <= T1)
            ev(s->check_in, 1, staff_at(i), s->room_no, s->handle,
               s->name, s->name_len);
        if (s->state == 2 && s->check_out >= T0 && s->check_out <= T1)
            ev(s->check_out, 2, staff_at(i + 4), s->room_no, s->handle,
               s->name, s->name_len);
    }
    for (i = 0; i < 14; i++) {
        struct stay *s = &STAYS[(i * 5 + 2) % N_OPEN];
        ev(span_band(9, 18), 3, staff_at(i + 1), s->room_no, s->handle,
           s->name, s->name_len);
    }
    for (i = 0; i < 8; i++) {
        struct stay *s = &STAYS[(i * 3 + 1) % N_OPEN];
        ev(span_band(9, 18), 4, staff_at(i + 2), s->room_no, s->handle,
           s->name, s->name_len);
    }
    for (i = 0; i < 18; i++) {
        uint32_t di = (i * 17 + 4) % (GUEST_N ? GUEST_N : 1u);
        struct door *d = door_find(GUEST_N ? GUEST_DOOR[di] : 1);
        ev_note(span_band(8, 17), 10, 0, i, staff_at(i + 3),
                d ? d->room_no : 0, d ? d->id : 0);
    }
    for (i = 0; i < 6; i++) {
        struct zone *z = &ZONES[(i * 3) % ZONE_MAX];
        ev(span_band(8, 17), 11, staff_at(i + 5), 0, z->id, z->name,
           strnlen((const char *)z->name, ZONE_NAME_LEN));
    }
    for (i = 0; i < 5; i++)
        ev_note(span_band(9, 17), 12, 0, i, staff_at(i + 6), 0,
                (i * 3) % SCHED_MAX + 1);
    for (i = 0; i < 2; i++)
        ev_note(span_band(10, 16), 13, 0, i, staff_at(i + 7), 0, 0);

    i = 0;
    while (JN < JRNL_MAX - 1) {
        uint32_t ts = (rnd() % 5u < 3u) ? span_band(19, 3) : span_band(7, 19);
        uint32_t di = GUEST_N ? (i * 23 + 7) % GUEST_N : 0;
        uint8_t reason = (uint8_t)(1 + rnd() % 8u);
        ev_note(ts, 8, reason, 0, 0, GUEST_N ? GUEST_ROOM[di] : 0,
                CRED_ID_BASE + (i % (ENC_N ? ENC_N : 1u)));
        i++;
    }
    ev_note(T1, 8, 5, 0, 0, 0, CRED_ID_BASE);

    for (i = 0; i + 1 < JN; i++) {
        uint32_t j, m = i;
        for (j = i + 1; j < JN; j++)
            if (JRNL[j].ts < JRNL[m].ts)
                m = j;
        if (m != i) {
            struct jrec tmp = JRNL[i];
            JRNL[i] = JRNL[m];
            JRNL[m] = tmp;
        }
    }
    for (i = 1; i < JN; i++)
        if (JRNL[i].ts <= JRNL[i - 1].ts)
            JRNL[i].ts = JRNL[i - 1].ts + 1u;
    for (i = 0; i < JN; i++)
        JRNL[i].id = i + 1;

    JRNL_FILL = JN;
    JRNL_HEAD = 0;
    JRNL_SEQ = JN + 1;
}

void seed_state(void)
{
    T0 = (uint32_t)SVC_BASE - (uint32_t)JRNL_MAX * 601u;
    T1 = (uint32_t)SVC_BASE - 47u;
    D0 = T0 / 86400u;
    D1 = T1 / 86400u;

    LCG = 0x5eed1234u;
    C_ENC0 = 118;
    C_VOID0 = 9;
    collect_rooms();
    seed_zones();
    seed_doors();
    seed_sched();
    seed_stays();
    build_encodes();
    seed_creds();
    seed_journal();
    EXP.get = EXP.buf;
    EXP.put = EXP.buf;
    EXP.records_rendered = 0;
    EXP.records_skipped = 0;
    EXP.batch_seq = 0;
}
