#ifndef KEXD_H
#define KEXD_H

#define _GNU_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define KX_PORT        1337
#define KX_MAGIC0      'K'
#define KX_MAGIC1      'X'
#define KX_MAGIC2      '0'
#define KX_MAGIC3      '1'
#define KX_BODY_MAX    4096
#define KX_RESP_BIT    0x01

#define ST_OK          0x00
#define ST_FRAME       0x01
#define ST_OPCODE      0x02
#define ST_BODY        0x03
#define ST_FULL        0x04
#define ST_NOENT       0x05
#define ST_STATE       0x06
#define ST_DENY        0x07

#define OP_HELLO            0x01
#define OP_DEVINFO          0x02
#define OP_CLOCK_GET        0x03
#define OP_CLOCK_SET        0x04
#define OP_DIAG_SELFTEST    0x05
#define OP_DIAG_TEXT        0x06
#define OP_COUNTERS         0x07
#define OP_SITE_INFO        0x08

#define OP_STAY_OPEN        0x10
#define OP_STAY_CLOSE       0x11
#define OP_STAY_GET         0x12
#define OP_STAY_LIST        0x13
#define OP_STAY_EXTEND      0x14
#define OP_STAY_MOVE        0x15
#define OP_OCCUPANCY        0x16

#define OP_CRED_ISSUE       0x20
#define OP_CRED_REISSUE     0x21
#define OP_CRED_VOID        0x22
#define OP_CRED_GET         0x23
#define OP_CRED_LIST        0x24
#define OP_CRED_VERIFY      0x25
#define OP_STAFF_CRED_ISSUE 0x26

#define OP_DOOR_LIST        0x30
#define OP_DOOR_GET         0x31
#define OP_DOOR_SET_FLAGS   0x32
#define OP_ZONE_LIST        0x33
#define OP_ZONE_GET         0x34
#define OP_ZONE_LOCKDOWN    0x35
#define OP_SCHED_LIST       0x36
#define OP_SCHED_SET        0x37
#define OP_DOOR_EXPORT      0x38

#define OP_STAFF_LIST       0x40
#define OP_STAFF_GET        0x41
#define OP_STAFF_SET_WINDOW 0x42

#define OP_JRNL_COUNT       0x50
#define OP_JRNL_GET         0x51
#define OP_JRNL_FIND        0x52
#define OP_JRNL_PEEK        0x53
#define OP_EXPORT_BEGIN     0x54
#define OP_EXPORT_FETCH     0x55
#define OP_EXPORT_STAT      0x56

#ifndef DOOR_MAX
#define DOOR_MAX       4199
#endif
#define ZONE_MAX       32
#define SCHED_MAX      64
#define STAFF_MAX      64
#define STAY_MAX       64
#define CRED_MAX       256
#define JRNL_MAX       384

#define NAME_MAX_LEN   64
#define NOTE_MAX_LEN   96
#define TEXT_CAP       96
#define STAFF_NAME_LEN 48
#define ZONE_NAME_LEN  24
#define LABEL_LEN      10
#define BUS_LEN        8
#define CARD_NO_LEN    19
#define FETCH_CAP      512
#define REGION_SZ      3072
#define REC_SLOTS      128
#define LIST_CAP       64
#define FIND_CAP       128
#define DIAG_CAP       640

#define BUILD_ID       0x00517a04u
#define SVC_BASE       98754317
#define CAPS_BITS      0x01ffu
#define TZ_MIN_DFLT    60
#define DST_DFLT       1
#define DRIFT_PPM      (-3)
#define CRED_ID_BASE   4096
#define SITE_NAME_LEN  40
#define SITE_ADDR_LEN  64
#define SITE_INST_LEN  32
#define SITE_TICK_LEN  16

struct door {
    uint16_t id;
    uint16_t room_no;
    uint8_t  zone;
    uint8_t  flags;
    uint8_t  model;
    uint8_t  fw;
    uint32_t last_seen;
    uint8_t  battery;
    uint8_t  bus_len;
    uint8_t  label[LABEL_LEN];
    uint8_t  bus[BUS_LEN];
};

struct zone {
    uint8_t  id;
    uint8_t  flags;
    uint16_t door_count;
    uint16_t curfew_start;
    uint16_t curfew_end;
    uint8_t  name[ZONE_NAME_LEN];
};

struct swin {
    uint8_t  id;
    uint8_t  zone;
    uint8_t  mode;
    uint8_t  days;
    uint16_t start_min;
    uint16_t end_min;
    uint32_t hits;
    uint8_t  in_use;
    uint8_t  pad[3];
};

struct staff {
    uint16_t id;
    uint8_t  klass;
    uint8_t  flags;
    uint8_t  days;
    uint8_t  pad0;
    uint16_t start_min;
    uint16_t end_min;
    uint16_t zone_mask;
    uint32_t cred_count;
    uint8_t  name[STAFF_NAME_LEN];
};

struct stay {
    uint32_t handle;
    uint16_t room_no;
    uint8_t  state;
    uint8_t  party;
    uint32_t check_in;
    uint32_t check_out;
    uint16_t cred_count;
    uint8_t  name_len;
    uint8_t  pad0;
    uint8_t  name[NAME_MAX_LEN];
    uint8_t  pad1[12];
};

struct cred {
    uint32_t id;
    uint32_t owner;
    uint32_t issued;
    uint32_t expires;
    uint16_t room_no;
    uint16_t zone_mask;
    uint8_t  klass;
    uint8_t  flags;
    uint8_t  seq;
    uint8_t  pad0;
    uint8_t  blob[8];
    uint8_t  pad1[16];
};

struct jrec {
    uint32_t id;
    uint32_t ts;
    uint8_t  kind;
    uint8_t  actor;
    uint16_t room_no;
    uint32_t subject;
    uint8_t  text_len;
    uint8_t  pad0[3];
    uint8_t  text[TEXT_CAP];
    uint8_t  pad1[12];
};

struct exp_state {
    uint16_t rec_end[REC_SLOTS];
    uint8_t  buf[REGION_SZ];
    uint32_t records_rendered;
    uint32_t records_skipped;
    uint8_t *get;
    uint8_t *put;
    uint32_t batch_seq;
};

struct devrec {
    uint8_t  serial[16];
    uint8_t  mac[6];
    uint8_t  hw_rev;
    uint8_t  fw_major;
    uint8_t  fw_minor;
    uint8_t  fw_patch;
    uint32_t build;
};

struct siterec {
    uint8_t  name[SITE_NAME_LEN];
    uint8_t  addr[SITE_ADDR_LEN];
    uint8_t  inst[SITE_INST_LEN];
    uint8_t  tick[SITE_TICK_LEN];
    uint16_t site_id;
};

extern struct jrec        JRNL[JRNL_MAX];
extern struct cred        CREDS[CRED_MAX];
extern struct stay        STAYS[STAY_MAX];
extern struct staff       STAFF[STAFF_MAX];
extern struct swin        SCHED[SCHED_MAX];
extern char               SITE_KEY[128];
extern struct zone        ZONES[ZONE_MAX];
extern struct door        DOORS[DOOR_MAX];
extern struct exp_state   EXP;

extern struct devrec DEV;
extern uint64_t  SUBKEY;
extern time_t    BOOT_TS;
extern uint32_t  JRNL_SEQ;
extern uint32_t  JRNL_FILL;
extern uint32_t  JRNL_HEAD;
extern uint32_t  CRED_SEQ;
extern uint32_t  C_ENC0;
extern uint32_t  C_VOID0;
extern uint32_t  SESS_ISSUED;
extern uint32_t  SESS_VOIDED;
extern int16_t   TZ_MIN;
extern uint8_t   DST_ON;

int  read_full(int fd, void *dst, size_t n);
int  write_full(int fd, const void *src, size_t n);
int  send_frame(int fd, uint8_t op, const uint8_t *body, size_t len);
int  send_status(int fd, uint8_t op, uint8_t st);
void put_u16(uint8_t *p, uint16_t v);
void put_u32(uint8_t *p, uint32_t v);
uint16_t get_u16(const uint8_t *p);
uint32_t get_u32(const uint8_t *p);
uint64_t fold64(const uint8_t *p, size_t n, uint64_t h);

uint32_t dev_seconds(void);
uint32_t dev_uptime(void);
uint32_t cnt_cards_encoded(void);
uint32_t cnt_cards_voided(void);
uint32_t cnt_head_cycles(void);
uint32_t cnt_head_faults(void);
uint32_t cnt_mains_events(void);
uint32_t cnt_reader_resets(void);
uint32_t cnt_reader_temp(void);
uint32_t cnt_sync_age(void);
uint32_t swin_hits(const struct swin *w);
uint32_t doors_provisioned(void);
uint32_t doors_online(void);
uint32_t doors_offline(void);
uint32_t doors_lowbatt(void);
uint32_t zones_in_service(void);
uint32_t zones_lockdown(void);
uint32_t stays_open(void);
uint32_t stays_closed(void);

void conf_load_all(void);
const uint8_t *pool_name(unsigned i);
const uint8_t *pool_note(unsigned i);
const uint8_t *pool_note_at(unsigned i);
const struct siterec *site_rec(void);
uint8_t note_index(uint8_t kind, uint8_t reason, uint32_t pick);
uint8_t zone_of_room(uint16_t room);
uint16_t guest_zone_mask(uint16_t room);
unsigned pool_name_count(void);
unsigned pool_note_count(void);
void seed_state(void);
uint16_t door_of_room(uint16_t room);

struct jrec *jrnl_find(uint32_t id);
void jrnl_add(uint8_t kind, uint8_t actor, uint16_t room_no, uint32_t subject,
              const uint8_t *text, uint8_t text_len);
struct stay *stay_find(uint32_t handle);
struct cred *cred_find(uint32_t id);
struct door *door_find(uint16_t id);
struct zone *zone_find(uint8_t id);
struct staff *staff_find(uint16_t id);
struct swin *swin_find(uint8_t id);

void region_reset(void);
int  jrnl_emit(const struct jrec *r);
int  door_emit(const struct door *d);
uint16_t jrnl_peek_line(const struct jrec *r, char *out, size_t cap);
uint16_t region_remaining(void);

int h_hello(int fd, const uint8_t *b, uint16_t len);
int h_devinfo(int fd, const uint8_t *b, uint16_t len);
int h_clock_get(int fd, const uint8_t *b, uint16_t len);
int h_clock_set(int fd, const uint8_t *b, uint16_t len);
int h_diag_selftest(int fd, const uint8_t *b, uint16_t len);
int h_diag_text(int fd, const uint8_t *b, uint16_t len);
int h_counters(int fd, const uint8_t *b, uint16_t len);
int h_site_info(int fd, const uint8_t *b, uint16_t len);
int h_stay_open(int fd, const uint8_t *b, uint16_t len);
int h_stay_close(int fd, const uint8_t *b, uint16_t len);
int h_stay_get(int fd, const uint8_t *b, uint16_t len);
int h_stay_list(int fd, const uint8_t *b, uint16_t len);
int h_stay_extend(int fd, const uint8_t *b, uint16_t len);
int h_stay_move(int fd, const uint8_t *b, uint16_t len);
int h_occupancy(int fd, const uint8_t *b, uint16_t len);
int h_cred_issue(int fd, const uint8_t *b, uint16_t len);
int h_cred_reissue(int fd, const uint8_t *b, uint16_t len);
int h_cred_void(int fd, const uint8_t *b, uint16_t len);
int h_cred_get(int fd, const uint8_t *b, uint16_t len);
int h_cred_list(int fd, const uint8_t *b, uint16_t len);
int h_cred_verify(int fd, const uint8_t *b, uint16_t len);
int h_staff_cred_issue(int fd, const uint8_t *b, uint16_t len);
int h_door_list(int fd, const uint8_t *b, uint16_t len);
int h_door_get(int fd, const uint8_t *b, uint16_t len);
int h_door_set_flags(int fd, const uint8_t *b, uint16_t len);
int h_zone_list(int fd, const uint8_t *b, uint16_t len);
int h_zone_get(int fd, const uint8_t *b, uint16_t len);
int h_zone_lockdown(int fd, const uint8_t *b, uint16_t len);
int h_sched_list(int fd, const uint8_t *b, uint16_t len);
int h_sched_set(int fd, const uint8_t *b, uint16_t len);
int h_door_export(int fd, const uint8_t *b, uint16_t len);
int h_staff_list(int fd, const uint8_t *b, uint16_t len);
int h_staff_get(int fd, const uint8_t *b, uint16_t len);
int h_staff_set_window(int fd, const uint8_t *b, uint16_t len);
int h_jrnl_count(int fd, const uint8_t *b, uint16_t len);
int h_jrnl_get(int fd, const uint8_t *b, uint16_t len);
int h_jrnl_find(int fd, const uint8_t *b, uint16_t len);
int h_jrnl_peek(int fd, const uint8_t *b, uint16_t len);
int h_export_begin(int fd, const uint8_t *b, uint16_t len);
int h_export_fetch(int fd, const uint8_t *b, uint16_t len);
int h_export_stat(int fd, const uint8_t *b, uint16_t len);

void cred_blob(struct cred *c);
uint16_t cred_card_no(const struct cred *c, char *out, size_t cap);
void cred_void_one(struct cred *c);

#endif
