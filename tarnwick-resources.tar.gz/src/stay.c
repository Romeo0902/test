#include "kexd.h"

/* ---- stays ---- */

static uint16_t void_creds_of(uint32_t owner)
{
    uint32_t i;
    uint16_t n = 0;

    for (i = 0; i < CRED_MAX; i++) {
        struct cred *c = &CREDS[i];
        if (c->id != 0 && c->owner == owner && (c->flags & 0x01)) {
            cred_void_one(c);
            n++;
        }
    }
    SESS_VOIDED += n;
    return n;
}

static int room_busy(uint16_t room, uint32_t skip)
{
    uint32_t i;

    for (i = 0; i < STAY_MAX; i++)
        if (STAYS[i].state == 1 && STAYS[i].room_no == room &&
            STAYS[i].handle != skip)
            return 1;
    return 0;
}

int h_stay_open(int fd, const uint8_t *b, uint16_t len)
{
    uint16_t room;
    uint8_t party, nights, nlen;
    uint32_t i;
    uint8_t out[13];
    struct stay *s;

    if (len < 5)
        return send_status(fd, OP_STAY_OPEN, ST_BODY);
    room = get_u16(b);
    party = b[2];
    nights = b[3];
    nlen = b[4];
    if (nlen > NAME_MAX_LEN || (uint16_t)(5 + nlen) != len)
        return send_status(fd, OP_STAY_OPEN, ST_BODY);
    if (party < 1 || party > 8 || nights < 1 || nights > 28)
        return send_status(fd, OP_STAY_OPEN, ST_BODY);
    if (door_of_room(room) == 0)
        return send_status(fd, OP_STAY_OPEN, ST_NOENT);
    if (room_busy(room, 0))
        return send_status(fd, OP_STAY_OPEN, ST_STATE);

    for (i = 0; i < STAY_MAX; i++)
        if (STAYS[i].state == 0)
            break;
    if (i == STAY_MAX)
        return send_status(fd, OP_STAY_OPEN, ST_FULL);

    s = &STAYS[i];
    memset(s, 0, sizeof *s);
    s->handle = i + 1;
    s->room_no = room;
    s->state = 1;
    s->party = party;
    s->check_in = dev_seconds();
    s->check_out = s->check_in + (uint32_t)nights * 86400u;
    s->name_len = nlen;
    if (nlen)
        memcpy(s->name, b + 5, nlen);

    jrnl_add(1, 0, room, s->handle, b + 5, nlen);

    out[0] = ST_OK;
    put_u32(out + 1, s->handle);
    put_u32(out + 5, s->check_in);
    put_u32(out + 9, s->check_out);
    return send_frame(fd, OP_STAY_OPEN, out, sizeof out);
}

int h_stay_close(int fd, const uint8_t *b, uint16_t len)
{
    struct stay *s;
    uint16_t nv;
    uint8_t out[7];

    if (len != 4)
        return send_status(fd, OP_STAY_CLOSE, ST_BODY);
    s = stay_find(get_u32(b));
    if (!s)
        return send_status(fd, OP_STAY_CLOSE, ST_NOENT);
    if (s->state != 1)
        return send_status(fd, OP_STAY_CLOSE, ST_STATE);

    nv = void_creds_of(s->handle);
    s->state = 2;
    s->check_out = dev_seconds();
    jrnl_add(2, 0, s->room_no, s->handle, s->name, s->name_len);

    out[0] = ST_OK;
    put_u32(out + 1, s->handle);
    put_u16(out + 5, nv);
    return send_frame(fd, OP_STAY_CLOSE, out, sizeof out);
}

int h_stay_get(int fd, const uint8_t *b, uint16_t len)
{
    struct stay *s;
    uint8_t out[86];

    if (len != 4)
        return send_status(fd, OP_STAY_GET, ST_BODY);
    s = stay_find(get_u32(b));
    if (!s)
        return send_status(fd, OP_STAY_GET, ST_NOENT);

    memset(out, 0, sizeof out);
    out[0] = ST_OK;
    put_u32(out + 1, s->handle);
    put_u16(out + 5, s->room_no);
    out[7] = s->state;
    out[8] = s->party;
    put_u32(out + 9, s->check_in);
    put_u32(out + 13, s->check_out);
    put_u16(out + 17, s->cred_count);
    out[19] = s->name_len;
    memcpy(out + 20, s->name, NAME_MAX_LEN);
    return send_frame(fd, OP_STAY_GET, out, 84);
}

int h_stay_list(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[3 + LIST_CAP * 8];
    uint8_t first, count, ret = 0;
    uint32_t i, total = 0, seen = 0;

    if (len != 2)
        return send_status(fd, OP_STAY_LIST, ST_BODY);
    first = b[0];
    count = b[1];
    if (count > LIST_CAP)
        return send_status(fd, OP_STAY_LIST, ST_BODY);

    for (i = 0; i < STAY_MAX; i++)
        if (STAYS[i].state != 0)
            total++;
    for (i = 0; i < STAY_MAX && ret < count; i++) {
        struct stay *s = &STAYS[i];
        uint8_t *p;
        if (s->state == 0)
            continue;
        if (seen++ < first)
            continue;
        p = out + 3 + 8 * ret;
        put_u32(p, s->handle);
        put_u16(p + 4, s->room_no);
        p[6] = s->state;
        p[7] = s->party;
        ret++;
    }
    out[0] = ST_OK;
    out[1] = ret;
    out[2] = (uint8_t)total;
    return send_frame(fd, OP_STAY_LIST, out, 3 + (size_t)ret * 8);
}

int h_stay_extend(int fd, const uint8_t *b, uint16_t len)
{
    struct stay *s;
    uint8_t nights;
    uint8_t out[9];

    if (len != 5)
        return send_status(fd, OP_STAY_EXTEND, ST_BODY);
    nights = b[4];
    if (nights < 1 || nights > 28)
        return send_status(fd, OP_STAY_EXTEND, ST_BODY);
    s = stay_find(get_u32(b));
    if (!s)
        return send_status(fd, OP_STAY_EXTEND, ST_NOENT);
    if (s->state != 1)
        return send_status(fd, OP_STAY_EXTEND, ST_STATE);
    if (s->check_out + (uint32_t)nights * 86400u >
        s->check_in + 90u * 86400u)
        return send_status(fd, OP_STAY_EXTEND, ST_DENY);

    s->check_out += (uint32_t)nights * 86400u;
    jrnl_add(3, 0, s->room_no, s->handle, s->name, s->name_len);

    out[0] = ST_OK;
    put_u32(out + 1, s->handle);
    put_u32(out + 5, s->check_out);
    return send_frame(fd, OP_STAY_EXTEND, out, sizeof out);
}

int h_stay_move(int fd, const uint8_t *b, uint16_t len)
{
    struct stay *s;
    uint16_t room, nv;
    uint8_t out[9];

    if (len != 6)
        return send_status(fd, OP_STAY_MOVE, ST_BODY);
    s = stay_find(get_u32(b));
    if (!s)
        return send_status(fd, OP_STAY_MOVE, ST_NOENT);
    room = get_u16(b + 4);
    if (s->state != 1)
        return send_status(fd, OP_STAY_MOVE, ST_STATE);
    if (door_of_room(room) == 0 || room_busy(room, s->handle))
        return send_status(fd, OP_STAY_MOVE, ST_STATE);

    nv = void_creds_of(s->handle);
    s->room_no = room;
    s->cred_count = 0;
    jrnl_add(4, 0, room, s->handle, s->name, s->name_len);

    out[0] = ST_OK;
    put_u32(out + 1, s->handle);
    put_u16(out + 5, room);
    put_u16(out + 7, nv);
    return send_frame(fd, OP_STAY_MOVE, out, sizeof out);
}

int h_occupancy(int fd, const uint8_t *b, uint16_t len)
{
    uint8_t out[2 + ZONE_MAX * 7];
    uint8_t zn = 0;
    uint32_t z, i;

    (void)b;
    if (len != 0)
        return send_status(fd, OP_OCCUPANCY, ST_BODY);

    for (z = 0; z < ZONE_MAX; z++) {
        uint16_t rooms = 0, occ = 0, guests = 0;
        uint8_t *p;
        if ((ZONES[z].flags & 0x01) == 0)
            continue;
        for (i = 0; i < DOOR_MAX; i++) {
            struct door *d = &DOORS[i];
            if (d->id == 0 || d->room_no == 0 || d->zone != z + 1)
                continue;
            rooms++;
            {
                uint32_t k;
                for (k = 0; k < STAY_MAX; k++) {
                    if (STAYS[k].state == 1 && STAYS[k].room_no == d->room_no) {
                        occ++;
                        guests = (uint16_t)(guests + STAYS[k].party);
                        break;
                    }
                }
            }
        }
        p = out + 2 + 7 * zn;
        p[0] = (uint8_t)(z + 1);
        put_u16(p + 1, rooms);
        put_u16(p + 3, occ);
        put_u16(p + 5, guests);
        zn++;
    }
    out[0] = ST_OK;
    out[1] = zn;
    return send_frame(fd, OP_OCCUPANCY, out, 2 + (size_t)zn * 7);
}
